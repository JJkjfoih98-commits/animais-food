extends Node
## AS MISSÕES DA FASE
## Cada fase tem 3 missões (veja FASES em scripts/dados.gd).
## O jogo avisa este script quando algo acontece (entregou, errou, cliente bravo)
## e ele confere se alguma missão foi cumprida. Cada missão cumprida = 1 estrela.

const Dados = preload("res://scripts/dados.gd")

signal cumprida(missao)

## Lista das missões de hoje. Cada uma é:
## {"dados": <linha da tabela>, "texto": "Sirva 5 clientes", "ok": false}
var lista: Array = []

# Contadores do dia
var atendidos := 0
var ganho := 0
var combo := 0          # entregas certas seguidas (zera se errar ou alguém sair bravo)
var maior_combo := 0
var teve_bravo := false
var por_comida := {}    # comida -> quantas foram servidas
var _horas_entrega: Array = []   # quando cada entrega aconteceu (para a "rajada")
var _relogio := 0.0


func preparar(missoes_da_fase: Array) -> void:
	lista.clear()
	for m in missoes_da_fase:
		var d: Dictionary = m.duplicate()
		# Se a comida da missão ainda não foi liberada, troca por uma liberada.
		if d["tipo"] == "comida" and not Estado.comidas_liberadas().has(d["comida"]):
			d["comida"] = Estado.comidas_liberadas().back()
		lista.append({"dados": d, "texto": Dados.texto_missao(d), "ok": false})


## Comida que alguma missão pede (os clientes pedem ela mais vezes).
func comida_da_missao() -> String:
	for m in lista:
		if m["dados"]["tipo"] == "comida" and not m["ok"]:
			return m["dados"]["comida"]
	return ""


func _process(delta: float) -> void:
	_relogio += delta


# ------------------------------------------------------------------ eventos do jogo

func entregou(comida: String, segundos_esperando: float, valor: int) -> void:
	atendidos += 1
	ganho += valor
	combo += 1
	maior_combo = maxi(maior_combo, combo)
	por_comida[comida] = por_comida.get(comida, 0) + 1
	_horas_entrega.append(_relogio)
	for m in lista:
		var d: Dictionary = m["dados"]
		if d["tipo"] == "rapido" and segundos_esperando <= d["meta"]:
			_cumprir(m)
	_conferir()


func errou() -> void:
	combo = 0


func cliente_bravo() -> void:
	combo = 0
	teve_bravo = true


## Fim do dia: confere as missões que só dá para saber no final.
func fim_do_dia(reputacao: float) -> void:
	for m in lista:
		var d: Dictionary = m["dados"]
		if d["tipo"] == "sem_bravo" and not teve_bravo:
			_cumprir(m)
		elif d["tipo"] == "estrelas" and reputacao >= d["meta"]:
			_cumprir(m)


func estrelas() -> int:
	return lista.filter(func(m): return m["ok"]).size()


# ------------------------------------------------------------------ conferir

func _conferir() -> void:
	for m in lista:
		var d: Dictionary = m["dados"]
		match d["tipo"]:
			"servir":
				if atendidos >= d["meta"]: _cumprir(m)
			"ganhar":
				if ganho >= d["meta"]: _cumprir(m)
			"combo":
				if maior_combo >= d["meta"]: _cumprir(m)
			"comida":
				if por_comida.get(d["comida"], 0) >= d["meta"]: _cumprir(m)
			"rajada":
				var recentes := _horas_entrega.filter(func(h): return _relogio - h <= 20.0)
				if recentes.size() >= d["meta"]: _cumprir(m)


func _cumprir(m: Dictionary) -> void:
	if m["ok"]:
		return
	m["ok"] = true
	cumprida.emit(m)


## Texto do progresso, ex.: "3/5" (ou "OK!" quando cumprida).
func progresso(m: Dictionary) -> String:
	if m["ok"]:
		return "OK!"
	var d: Dictionary = m["dados"]
	match d["tipo"]:
		"servir": return "%d/%d" % [atendidos, d["meta"]]
		"ganhar": return "$%d/%d" % [ganho, d["meta"]]
		"combo": return "%d/%d" % [combo, d["meta"]]
		"comida": return "%d/%d" % [por_comida.get(d["comida"], 0), d["meta"]]
		"rajada": return "%d/%d" % [_horas_entrega.filter(func(h): return _relogio - h <= 20.0).size(), d["meta"]]
		"sem_bravo": return "falhou" if teve_bravo else "indo bem"
		"estrelas": return "no fim"
		"rapido": return "tente!"
	return "..."
