extends Control
## Uma mesa do restaurante: recebe um cliente, mostra o pedido e a paciência.

signal tocada(mesa)
signal paciencia_esgotada(mesa)

enum { VAZIA, CHEGANDO, ESPERANDO, SAINDO }

@export var numero := 1

var estado := VAZIA
var animal := ""
var pedido := ""
var paciencia_total := 1.0
var paciencia := 1.0

@onready var cliente: TextureRect = $Cliente
@onready var balao: Panel = $Balao
@onready var icone_pedido: TextureRect = $Balao/Comida
@onready var barra: ProgressBar = $Paciencia
@onready var rotulo: Label = $Numero


func _ready() -> void:
	rotulo.text = "Mesa %d" % numero
	$Botao.pressed.connect(func(): tocada.emit(self))
	_limpar()


func esta_livre() -> bool:
	return estado == VAZIA


func esta_esperando() -> bool:
	return estado == ESPERANDO


func fracao_paciencia() -> float:
	return paciencia / paciencia_total


func chegar(novo_animal: String, nova_comida: String, segundos: float) -> void:
	animal = novo_animal
	pedido = nova_comida
	paciencia_total = segundos
	paciencia = segundos
	estado = CHEGANDO
	cliente.texture = Estado.textura(animal)
	cliente.visible = true
	cliente.modulate.a = 0.0
	cliente.position.y = 60
	var t := create_tween().set_parallel()
	t.tween_property(cliente, "modulate:a", 1.0, 0.4)
	t.tween_property(cliente, "position:y", 110.0, 0.4).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	t.chain().tween_callback(_sentou)


func _sentou() -> void:
	estado = ESPERANDO
	Som.tocar("cliente_chega")
	icone_pedido.texture = Estado.textura(pedido)
	balao.visible = true
	barra.visible = true
	balao.scale = Vector2(0.2, 0.2)
	create_tween().tween_property(balao, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func _process(delta: float) -> void:
	if estado != ESPERANDO:
		return
	paciencia -= delta
	barra.value = fracao_paciencia() * 100.0
	var f := fracao_paciencia()
	barra.modulate = Color(0.3, 0.85, 0.3) if f > 0.5 else (Color(1, 0.8, 0.2) if f > 0.25 else Color(1, 0.3, 0.25))
	if paciencia <= 0.0:
		_ir_embora("bravo")
		paciencia_esgotada.emit(self)


## Tenta entregar uma comida. Devolve true se era o pedido certo.
func servir(comida: String) -> bool:
	if estado != ESPERANDO:
		return false
	if comida == pedido:
		_ir_embora("sorriso")
		return true
	# Pedido errado: o balão treme e o cliente perde um pouco de paciência.
	paciencia = maxf(0.1, paciencia - paciencia_total * 0.15)
	var x := balao.position.x
	var t := create_tween()
	for i in 3:
		t.tween_property(balao, "position:x", x - 10, 0.05)
		t.tween_property(balao, "position:x", x + 10, 0.05)
	t.tween_property(balao, "position:x", x, 0.05)
	return false


func _ir_embora(emocao: String) -> void:
	estado = SAINDO
	barra.visible = false
	icone_pedido.texture = Estado.textura(emocao)
	var t := create_tween()
	t.tween_interval(0.7)
	t.tween_property(cliente, "modulate:a", 0.0, 0.35)
	t.parallel().tween_property(balao, "modulate:a", 0.0, 0.35)
	t.tween_callback(_limpar)


func _limpar() -> void:
	estado = VAZIA
	cliente.visible = false
	balao.visible = false
	balao.modulate.a = 1.0
	barra.visible = false
	pedido = ""
	animal = ""
