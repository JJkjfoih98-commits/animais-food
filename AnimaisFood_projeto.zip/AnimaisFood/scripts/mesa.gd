extends Node2D
## UMA MESA DO PÁTIO
## Recebe um cliente (animal) e mostra em cima dele:
##   - o balão com a comida que ele pediu;
##   - o coração da paciência (vai esvaziando);
##   - a barrinha azul do preparo (enche enquanto o chef cozinha o prato dele)
##     e um sininho quando o prato está pronto no balcão.

signal paciencia_esgotada(mesa)

enum { VAZIA, CHEGANDO, ESPERANDO, SAINDO }

@export var numero := 1

var estado := VAZIA
var pedido := ""            # comida que o cliente quer
var paciencia_total := 1.0  # segundos que ele aguenta esperar
var paciencia := 1.0        # segundos que ainda faltam
var _tempo := 0.0           # usado nas animações
var _fase := 0.0            # cada mesa balança num ritmo diferente
var esperando_ha := 0.0     # segundos desde que o cliente sentou
var _preparo := -1.0        # progresso do prato na cozinha (-1 = sem pedido)

@onready var cliente: Node2D = $Cliente
@onready var animal: Sprite2D = $Cliente/Animal
@onready var balao: Sprite2D = $Balao
@onready var icone_pedido: Sprite2D = $Balao/Comida
@onready var coracao: TextureProgressBar = $Coracao
@onready var barra_preparo: ProgressBar = $Preparo
@onready var sino: Sprite2D = $Sino


func _ready() -> void:
	$Numero.text = "Mesa %d" % numero
	_fase = numero * 1.7
	_limpar()


func esta_livre() -> bool:
	return estado == VAZIA


func esta_esperando() -> bool:
	return estado == ESPERANDO


func fracao_paciencia() -> float:
	return paciencia / paciencia_total


## Um cliente novo chega e senta nesta mesa.
func chegar(nome_animal: String, comida: String, segundos: float) -> void:
	pedido = comida
	paciencia_total = segundos
	paciencia = segundos
	estado = CHEGANDO
	animal.texture = Estado.textura(nome_animal)
	cliente.visible = true
	cliente.modulate = Color(1, 1, 1, 0)
	cliente.position.y = -150
	# Animação de chegada: aparece e cai na cadeira com um pulinho.
	var t := create_tween().set_parallel()
	t.tween_property(cliente, "modulate:a", 1.0, 0.3)
	t.tween_property(cliente, "position:y", -70.0, 0.5).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
	t.chain().tween_callback(_sentou)


func _sentou() -> void:
	estado = ESPERANDO
	esperando_ha = 0.0
	barra_preparo.visible = _preparo >= 0.0
	Som.tocar("cliente_chega")
	icone_pedido.texture = Estado.textura(pedido)
	balao.visible = true
	coracao.visible = true
	balao.scale = Vector2(0.05, 0.05)
	create_tween().tween_property(balao, "scale", Vector2(0.38, 0.38), 0.3).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func _process(delta: float) -> void:
	_tempo += delta
	if estado == VAZIA:
		return
	# Animação parada: o cliente balança de leve.
	animal.rotation = sin(_tempo * 2.5 + _fase) * 0.07
	animal.scale = Vector2.ONE * (0.46 + sin(_tempo * 5.0 + _fase) * 0.01)
	if estado != ESPERANDO:
		return

	# A paciência vai acabando... (mais devagar enquanto o prato está no fogo)
	esperando_ha += delta
	paciencia -= delta * (0.5 if _preparo > 0.0 else 1.0)
	var f := fracao_paciencia()
	coracao.value = f * 100.0
	coracao.tint_progress = Color(1, 1, 1) if f > 0.3 else Color(1, 0.55 + 0.45 * sin(_tempo * 12.0), 0.55)
	# Com pouca paciência, o cliente treme e o balão pisca.
	if f < 0.3:
		animal.position.x = sin(_tempo * 40.0) * 2.0
		balao.modulate.a = 0.6 + 0.4 * absf(sin(_tempo * 6.0))
	if paciencia <= 0.0:
		_ir_embora(false)
		paciencia_esgotada.emit(self)


## Mostra a barrinha do preparo (fracao de 0 = começando até 1 = pronto).
func mostrar_preparo(fracao: float) -> void:
	_preparo = fracao
	barra_preparo.value = fracao * 100.0
	barra_preparo.visible = estado == ESPERANDO


## O prato deste cliente está pronto no balcão: aparece o sininho.
func mostrar_pronto() -> void:
	mostrar_preparo(1.0)
	sino.visible = estado == ESPERANDO


## O garçom entrega uma comida. Devolve true se era o pedido certo.
func servir(comida: String) -> bool:
	if estado != ESPERANDO:
		return false
	if comida == pedido:
		_ir_embora(true)
		return true
	# Pedido errado: o balão treme e o cliente perde um pouco de paciência.
	paciencia = maxf(0.1, paciencia - paciencia_total * 0.15)
	var x := balao.position.x
	var t := create_tween()
	for i in 3:
		t.tween_property(balao, "position:x", x - 12, 0.05)
		t.tween_property(balao, "position:x", x + 12, 0.05)
	t.tween_property(balao, "position:x", x, 0.05)
	return false


## O cliente vai embora feliz (comeu) ou bravo (cansou de esperar).
func _ir_embora(feliz: bool) -> void:
	estado = SAINDO
	coracao.visible = false
	barra_preparo.visible = false
	sino.visible = false
	balao.modulate.a = 1.0
	animal.position.x = 0.0
	icone_pedido.texture = Estado.textura("sorriso" if feliz else "bravo")
	var t := create_tween()
	if feliz:
		# Pulinho de alegria
		t.tween_property(cliente, "position:y", -100.0, 0.15).set_ease(Tween.EASE_OUT)
		t.tween_property(cliente, "position:y", -70.0, 0.15).set_ease(Tween.EASE_IN)
		t.tween_interval(0.5)
	else:
		# Fica vermelho de raiva
		t.tween_property(cliente, "modulate", Color(1, 0.4, 0.4), 0.2)
		t.tween_interval(0.7)
	t.tween_property(cliente, "modulate:a", 0.0, 0.35)
	t.parallel().tween_property(balao, "modulate:a", 0.0, 0.35)
	t.tween_callback(_limpar)


func _limpar() -> void:
	estado = VAZIA
	pedido = ""
	cliente.visible = false
	cliente.modulate = Color.WHITE
	balao.visible = false
	balao.modulate.a = 1.0
	coracao.visible = false
	barra_preparo.visible = false
	sino.visible = false
	_preparo = -1.0


## Sombra da mesa e cadeira (desenhadas antes do cliente e do tampo).
func _draw() -> void:
	draw_set_transform(Vector2(0, 30), 0.0, Vector2(1.0, 0.45))
	draw_circle(Vector2.ZERO, 80.0, Color(0, 0, 0, 0.18))
	draw_set_transform(Vector2.ZERO)
	# Cadeira atrás da mesa (onde o cliente senta)
	draw_rect(Rect2(-38, -96, 76, 46), Color(0.55, 0.32, 0.16))
	draw_rect(Rect2(-32, -90, 64, 34), Color(0.75, 0.48, 0.26))
