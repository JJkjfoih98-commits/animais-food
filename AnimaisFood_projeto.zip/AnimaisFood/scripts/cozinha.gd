extends Node2D
## A COZINHA VIVA: fila de pedidos, o Chef Elefante seguindo a RECEITA e o balcão.
## Como o chef faz um prato (veja _fazer_prato):
##   1) anda até a GELADEIRA, abre a porta e pega os ingredientes da receita;
##      (se você comprou a Ajudante Coelha, ELA busca e traz para ele)
##   2) leva até a ESTAÇÃO da receita: fogão (panela), forno, máquina de
##      sorvete ou bancada (tábua), e cozinha/monta;
##   3) leva o prato pronto até o BALCÃO, onde aparece com um sininho.
## O tempo de cada passo vem do "preparo" da comida (scripts/dados.gd).
## A barra laranja em cima do chef (e a azul em cima do cliente) mostram o progresso.

const Dados = preload("res://scripts/dados.gd")

signal prato_pronto(pedido)

## Lugares para pratos prontos no balcão (posições dentro do nó Balcao).
const VAGAS_BALCAO := [Vector2(0, 240), Vector2(0, 350), Vector2(0, 460), Vector2(0, 570)]
const FILA_VISIVEL := 3

# Como o tempo de preparo é dividido entre os passos (soma = 1.0)
const PARTE_GELADEIRA := 0.25   # ir até a geladeira e pegar os ingredientes
const PARTE_LEVAR := 0.10       # levar os ingredientes até a estação
const PARTE_COZINHAR := 0.55    # cozinhar / assar / montar
const PARTE_BALCAO := 0.10      # levar o prato até o balcão
const DESCONTO_AJUDANTE := 0.75 # com a ajudante, o prato fica 25% mais rápido

const DESCANSO_CHEF := Vector2(165, 262)
const DESCANSO_AJUDANTE := Vector2(192, 440)

## Cada pedido é um dicionário:
## {"mesa": <mesa>, "comida": "pizza", "estado": "fila"/"cozinhando"/"pronto",
##  "tempo": segundos de preparo, "feito": segundos já passados, "prato": nó do prato}
var pedidos: Array = []
var atual := {}                 # o pedido que o chef está fazendo agora
var _ajudante_entregou := false

@onready var chef = $Chef
@onready var ajudante = $Ajudante
@onready var geladeira = $Geladeira
@onready var fogao = $Fogao
@onready var sorveteira = $Sorveteira
@onready var bancada = $Bancada
@onready var pratos: Node2D = $Balcao/Pratos
@onready var tickets: Node2D = $Tickets


func _ready() -> void:
	ajudante.visible = tem_ajudante()
	chef.get_node("Barra").visible = false
	chef.get_node("Prato").visible = false
	fogao.get_node("Vapor").texture = _bolinha_de_fumaca()
	_mostrar_tickets()


func tem_ajudante() -> bool:
	return Estado.melhorias["ajudante"] > 0


## Segundos que um prato leva (com o desconto da ajudante, se tiver).
func tempo_total(comida: String) -> float:
	return Estado.tempo_preparo(comida) * (DESCONTO_AJUDANTE if tem_ajudante() else 1.0)


# ------------------------------------------------------------------ pedidos

func novo_pedido(mesa, comida: String) -> void:
	pedidos.append({"mesa": mesa, "comida": comida, "estado": "fila",
		"tempo": tempo_total(comida), "feito": 0.0, "prato": null})
	mesa.mostrar_preparo(0.0)


## O cliente foi embora: tira o pedido dele da fila, do fogão ou do balcão.
func cancelar(mesa) -> void:
	for p in pedidos.duplicate():
		if p["mesa"] == mesa:
			_remover(p)


## Um pedido pronto no balcão perto da posição "pos" (ou {} se não tiver).
func prato_perto(pos: Vector2, distancia: float) -> Dictionary:
	var melhor := {}
	for p in pedidos:
		if p["estado"] == "pronto":
			var d: float = pos.distance_to(p["prato"].global_position)
			if d < distancia:
				distancia = d
				melhor = p
	return melhor


## O garçom pegou este prato do balcão.
func retirar(pedido: Dictionary) -> void:
	_remover(pedido)


## O garçom entregou o prato da mesa "de" para a mesa "para" (mesma comida):
## o pedido que era da mesa "para" passa a ser da mesa "de".
func trocar_dono(de, para) -> void:
	for p in pedidos:
		if p["mesa"] == para:
			if de.esta_esperando():
				p["mesa"] = de
			else:
				_remover(p)
			return


func quantos(estado: String) -> int:
	return pedidos.filter(func(p): return p["estado"] == estado).size()


func _remover(p: Dictionary) -> void:
	if p["prato"]:
		p["prato"].queue_free()
	pedidos.erase(p)


# ------------------------------------------------------------------ a cada quadro

func _process(delta: float) -> void:
	# 1) Chef livre começa o próximo pedido da fila (se tiver vaga no balcão).
	if atual.is_empty() and quantos("pronto") < VAGAS_BALCAO.size():
		var proximo = _primeiro_da_fila()
		if proximo:
			atual = proximo
			atual["estado"] = "cozinhando"
			_fazer_prato(atual)   # começa a receita (ela continua sozinha)
	# 2) Progresso do prato que está sendo feito
	var barra: ProgressBar = chef.get_node("Barra")
	barra.visible = not atual.is_empty()
	chef.get_node("Prato").visible = barra.visible
	if not atual.is_empty():
		atual["feito"] += delta
		var f: float = clampf(atual["feito"] / atual["tempo"], 0.0, 0.99)
		barra.value = f * 100.0
		chef.get_node("Prato").texture = Estado.textura(atual["comida"])
		atual["mesa"].mostrar_preparo(f)
		for estacao in [fogao, sorveteira, bancada]:
			estacao.progresso = f
	_mostrar_tickets()


func _primeiro_da_fila():
	for p in pedidos:
		if p["estado"] == "fila":
			return p
	return null


# ------------------------------------------------------------------ A RECEITA

## Faz um prato seguindo a receita. Cada "await" espera um passo terminar.
func _fazer_prato(p: Dictionary) -> void:
	var receita: Dictionary = Dados.COMIDAS[p["comida"]]
	var t: float = Estado.tempo_preparo(p["comida"])   # tempo sem desconto
	var estacao: Node2D = _estacao(receita["estacao"])
	var ingredientes: Array = receita["ingredientes"].map(func(i): return "ing_" + i)

	# 1) INGREDIENTES DA GELADEIRA
	if tem_ajudante():
		# A Coelha busca enquanto o chef já vai para a estação.
		_ajudante_buscar(ingredientes, estacao, t * PARTE_GELADEIRA * DESCONTO_AJUDANTE)
		await chef.andar_ate(estacao.ponto(), t * PARTE_LEVAR * DESCONTO_AJUDANTE)
		while not _ajudante_entregou:
			await _esperar(0.05)
		t *= DESCONTO_AJUDANTE
	else:
		await chef.andar_ate(geladeira.ponto(), t * PARTE_GELADEIRA * 0.5)
		chef.olhar_para(geladeira.global_position.x)
		await geladeira.abrir()
		for ing in ingredientes:
			chef.itens.append(ing)                     # tira um ingrediente
			await _esperar(t * PARTE_GELADEIRA * 0.3 / ingredientes.size())
		await geladeira.fechar()
		await chef.andar_ate(estacao.ponto(), t * PARTE_LEVAR)
	if not pedidos.has(p):
		_desistir()
		return

	# 2) COZINHAR NA ESTAÇÃO DA RECEITA
	chef.olhar_para(estacao.global_position.x)
	chef.itens.clear()                                 # coloca os ingredientes
	await _cozinhar(p["comida"], receita["estacao"], ingredientes, t * PARTE_COZINHAR)
	if not pedidos.has(p):
		_desistir()
		return

	# 3) PRATO PRONTO: leva até o balcão
	chef.itens = [p["comida"]]
	var vaga := _vaga_livre()
	await chef.andar_ate(Vector2(212, vaga.y + 24), t * PARTE_BALCAO)
	chef.olhar_para(400)
	chef.itens.clear()
	if pedidos.has(p):
		_ficou_pronto(p, vaga)
	atual = {}
	chef.andar_ate(DESCANSO_CHEF, 0.6)


## Cozinha de acordo com a estação (cada uma tem sua animação).
func _cozinhar(comida: String, tipo: String, ingredientes: Array, segundos: float) -> void:
	Som.tocar("cozinhando")
	match tipo:
		"fogao":
			fogao.comida_panela = comida            # a comida aparece na panela
			await chef.trabalhar("mexendo", segundos)
			fogao.comida_panela = ""
		"forno":
			chef.acao = "forno"
			await fogao.abrir_forno()                # abre, põe a assadeira, fecha
			fogao.comida_forno = comida
			await fogao.fechar_forno()
			chef.acao = "parado"
			await _esperar(maxf(segundos - 1.2, 0.2))  # assando...
			chef.acao = "forno"
			await fogao.abrir_forno()                # abre e tira o prato
			fogao.comida_forno = ""
			chef.acao = "parado"
			fogao.fechar_forno()
		"sorveteira":
			sorveteira.comida = comida
			await chef.trabalhar("alavanca", segundos)
			sorveteira.comida = ""
		"bancada":
			bancada.comida = comida
			bancada.ingredientes = ingredientes
			await chef.trabalhar("picando", segundos)
			bancada.comida = ""


func _estacao(tipo: String) -> Node2D:
	match tipo:
		"forno": return fogao
		"sorveteira": return sorveteira
		"bancada": return bancada
	return fogao


## A AJUDANTE COELHA: vai à geladeira, pega os ingredientes e leva ao chef.
func _ajudante_buscar(ingredientes: Array, estacao: Node2D, segundos: float) -> void:
	_ajudante_entregou = false
	await ajudante.andar_ate(geladeira.ponto(), segundos * 0.35)
	ajudante.olhar_para(geladeira.global_position.x)
	await geladeira.abrir()
	ajudante.itens = ingredientes.duplicate()
	await geladeira.fechar()
	await ajudante.andar_ate(estacao.ponto() + Vector2(36, 8), segundos * 0.35)
	ajudante.olhar_para(chef.global_position.x)
	ajudante.itens.clear()                             # entregou para o chef
	_ajudante_entregou = true
	ajudante.andar_ate(DESCANSO_AJUDANTE, 0.8)


## O cliente foi embora no meio do preparo: limpa tudo e volta a descansar.
func _desistir() -> void:
	chef.itens.clear()
	chef.acao = "parado"
	fogao.comida_panela = ""
	fogao.comida_forno = ""
	sorveteira.comida = ""
	bancada.comida = ""
	atual = {}
	chef.andar_ate(DESCANSO_CHEF, 0.6)


## Espera alguns segundos (pausa junto com o jogo).
func _esperar(segundos: float) -> void:
	var t := create_tween()
	t.tween_interval(maxf(segundos, 0.05))
	await t.finished


# ------------------------------------------------------------------ balcão

## O prato ficou pronto: aparece no balcão com o número da mesa e um sininho.
func _ficou_pronto(p: Dictionary, vaga: Vector2) -> void:
	p["estado"] = "pronto"
	p["feito"] = p["tempo"]
	var prato := Sprite2D.new()
	prato.texture = Estado.textura("prato")
	prato.scale = Vector2(0.36, 0.36)
	prato.position = vaga
	var comida := Sprite2D.new()
	comida.texture = Estado.textura(p["comida"])
	comida.scale = Vector2(0.75, 0.75)
	comida.position = Vector2(0, -12)
	prato.add_child(comida)
	var sino := Sprite2D.new()
	sino.name = "Sino"
	sino.texture = Estado.textura("sininho")
	sino.scale = Vector2(0.5, 0.5)
	sino.position = Vector2(110, -110)
	prato.add_child(sino)
	var etiqueta := Label.new()
	etiqueta.text = "M%d" % p["mesa"].numero
	etiqueta.add_theme_font_size_override("font_size", 60)
	etiqueta.add_theme_color_override("font_color", Color.WHITE)
	etiqueta.add_theme_color_override("font_outline_color", Color(0.55, 0.25, 0.12))
	etiqueta.add_theme_constant_override("outline_size", 16)
	etiqueta.position = Vector2(-190, -60)
	prato.add_child(etiqueta)
	pratos.add_child(prato)
	p["prato"] = prato
	p["mesa"].mostrar_pronto()
	Som.tocar("pronto")
	var t := sino.create_tween().set_loops()   # o sininho balança (para quando o prato sai)
	t.tween_property(sino, "rotation", 0.4, 0.1)
	t.tween_property(sino, "rotation", -0.4, 0.1)
	prato_pronto.emit(p)


func _vaga_livre() -> Vector2:
	for v in VAGAS_BALCAO:
		var ocupada := false
		for p in pedidos:
			if p["prato"] and p["prato"].position == v:
				ocupada = true
		if not ocupada:
			return v
	return VAGAS_BALCAO[0]


## Mostra os pedidos que estão esperando na fila (no máximo 3 tickets e "+N").
func _mostrar_tickets() -> void:
	var fila := pedidos.filter(func(p): return p["estado"] == "fila")
	for i in FILA_VISIVEL:
		var t: Sprite2D = tickets.get_node("T%d" % (i + 1))
		t.visible = i < fila.size()
		if t.visible:
			t.get_node("Comida").texture = Estado.textura(fila[i]["comida"])
	var mais: Label = tickets.get_node("Mais")
	mais.visible = fila.size() > FILA_VISIVEL
	mais.text = "+%d" % (fila.size() - FILA_VISIVEL)


## Desenha uma bolinha branca e macia para o vapor da panela.
func _bolinha_de_fumaca() -> Texture2D:
	var img := Image.create(24, 24, false, Image.FORMAT_RGBA8)
	for y in 24:
		for x in 24:
			var d := Vector2(x - 11.5, y - 11.5).length() / 12.0
			img.set_pixel(x, y, Color(1, 1, 1, clampf(1.0 - d, 0.0, 1.0)))
	return ImageTexture.create_from_image(img)
