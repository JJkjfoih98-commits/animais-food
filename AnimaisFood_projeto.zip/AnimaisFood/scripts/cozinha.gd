extends Node2D
## A COZINHA: fila de pedidos, cozinheiros e balcão.
## Como funciona:
##   1) Um cliente senta e faz o pedido -> o pedido entra na FILA do chef.
##   2) O Chef Elefante (e a Ajudante Coelha, se você comprou) pega o primeiro
##      pedido da fila e cozinha durante o "tempo de preparo" daquela comida.
##      Uma barrinha em cima do chef (e em cima do cliente) mostra o progresso.
##   3) Quando termina, o prato aparece no BALCÃO com um sininho.
##   4) O garçom Totó pega o prato no balcão e leva até a mesa.
##
## Cada pedido é um dicionário assim:
##   {"mesa": <a mesa>, "comida": "pizza", "estado": "fila" / "cozinhando" / "pronto",
##    "tempo": segundos de preparo, "feito": segundos já cozinhados, "prato": nó do prato}

signal prato_pronto(pedido)

## Lugares para pratos prontos no balcão (posições dentro do nó Balcao).
const VAGAS_BALCAO := [Vector2(0, 240), Vector2(0, 350), Vector2(0, 460), Vector2(0, 570)]
const FILA_VISIVEL := 3   # quantos tickets aparecem em cima da cozinha

var pedidos: Array = []
var _trabalho := {}       # cozinheiro -> pedido que ele está fazendo
var _tempo := 0.0

@onready var chef: Node2D = $Chef
@onready var ajudante: Node2D = $Ajudante
@onready var pratos: Node2D = $Balcao/Pratos
@onready var tickets: Node2D = $Tickets


func _ready() -> void:
	# A Ajudante Coelha só aparece se a melhoria foi comprada.
	ajudante.visible = Estado.melhorias["ajudante"] > 0
	var fumaca := _bolinha_de_fumaca()
	for c in [chef, ajudante]:
		c.get_node("Barra").visible = false
		c.get_node("Vapor").texture = fumaca
		c.get_node("Vapor").emitting = false
		c.get_node("Prato").visible = false
	_mostrar_tickets()


## Desenha uma bolinha branca e macia para o vapor da panela.
func _bolinha_de_fumaca() -> Texture2D:
	var img := Image.create(24, 24, false, Image.FORMAT_RGBA8)
	for y in 24:
		for x in 24:
			var d := Vector2(x - 11.5, y - 11.5).length() / 12.0
			img.set_pixel(x, y, Color(1, 1, 1, clampf(1.0 - d, 0.0, 1.0)))
	return ImageTexture.create_from_image(img)


## Os cozinheiros que estão trabalhando hoje.
func cozinheiros() -> Array:
	return [chef, ajudante] if ajudante.visible else [chef]


# ------------------------------------------------------------------ pedidos

func novo_pedido(mesa, comida: String) -> void:
	pedidos.append({"mesa": mesa, "comida": comida, "estado": "fila",
		"tempo": Estado.tempo_preparo(comida), "feito": 0.0, "prato": null})
	mesa.mostrar_preparo(0.0)


## O cliente foi embora: tira o pedido dele da fila, do fogão ou do balcão.
func cancelar(mesa) -> void:
	for p in pedidos.duplicate():
		if p["mesa"] == mesa:
			_remover(p)


## Um pedido pronto no balcão perto da posição "pos" (ou {} se não tiver).
func prato_perto(pos: Vector2, distancia: float) -> Dictionary:
	var melhor := {}
	for p in pedidos:
		if p["estado"] == "pronto":
			var d: float = pos.distance_to(p["prato"].global_position)
			if d < distancia:
				distancia = d
				melhor = p
	return melhor


## O garçom pegou este prato do balcão.
func retirar(pedido: Dictionary) -> void:
	_remover(pedido)


## O garçom entregou o prato da mesa "de" para a mesa "para" (mesma comida):
## o pedido que era da mesa "para" passa a ser da mesa "de".
func trocar_dono(de, para) -> void:
	for p in pedidos:
		if p["mesa"] == para:
			if de.esta_esperando():
				p["mesa"] = de
			else:
				_remover(p)
			return


func quantos(estado: String) -> int:
	return pedidos.filter(func(p): return p["estado"] == estado).size()


func _remover(p: Dictionary) -> void:
	for c in _trabalho.keys():
		if _trabalho[c] == p:
			_trabalho.erase(c)
	if p["prato"]:
		p["prato"].queue_free()
	pedidos.erase(p)


# ------------------------------------------------------------------ a cada quadro

func _process(delta: float) -> void:
	_tempo += delta
	# 1) Cozinheiro livre pega o próximo pedido da fila (se tiver vaga no balcão).
	for c in cozinheiros():
		if not _trabalho.has(c):
			var vaga_livre := quantos("pronto") + _trabalho.size() < VAGAS_BALCAO.size()
			var proximo = _primeiro_da_fila()
			if proximo and vaga_livre:
				proximo["estado"] = "cozinhando"
				_trabalho[c] = proximo
				Som.tocar("cozinhando")
	# 2) Cozinha um pouquinho cada pedido que está no fogo.
	for c in _trabalho.keys():
		var p: Dictionary = _trabalho[c]
		p["feito"] += delta
		p["mesa"].mostrar_preparo(p["feito"] / p["tempo"])
		if p["feito"] >= p["tempo"]:
			_trabalho.erase(c)
			_ficou_pronto(p)
	# 3) Animações e tickets.
	for c in cozinheiros():
		_animar(c)
	_mostrar_tickets()


func _primeiro_da_fila():
	for p in pedidos:
		if p["estado"] == "fila":
			return p
	return null


## O prato ficou pronto: aparece no balcão com o número da mesa e um sininho.
func _ficou_pronto(p: Dictionary) -> void:
	p["estado"] = "pronto"
	var prato := Sprite2D.new()
	prato.texture = Estado.textura("prato")
	prato.scale = Vector2(0.36, 0.36)
	prato.position = _vaga_livre()
	var comida := Sprite2D.new()
	comida.texture = Estado.textura(p["comida"])
	comida.scale = Vector2(0.75, 0.75)
	comida.position = Vector2(0, -12)
	prato.add_child(comida)
	var sino := Sprite2D.new()
	sino.name = "Sino"
	sino.texture = Estado.textura("sininho")
	sino.scale = Vector2(0.5, 0.5)
	sino.position = Vector2(110, -110)
	prato.add_child(sino)
	var etiqueta := Label.new()
	etiqueta.text = "M%d" % p["mesa"].numero
	etiqueta.add_theme_font_size_override("font_size", 60)
	etiqueta.add_theme_color_override("font_color", Color.WHITE)
	etiqueta.add_theme_color_override("font_outline_color", Color(0.55, 0.25, 0.12))
	etiqueta.add_theme_constant_override("outline_size", 16)
	etiqueta.position = Vector2(-190, -60)
	prato.add_child(etiqueta)
	pratos.add_child(prato)
	p["prato"] = prato
	p["mesa"].mostrar_pronto()
	Som.tocar("pronto")
	prato_pronto.emit(p)


func _vaga_livre() -> Vector2:
	for v in VAGAS_BALCAO:
		var ocupada := false
		for p in pedidos:
			if p["prato"] and p["prato"].position == v:
				ocupada = true
		if not ocupada:
			return v
	return VAGAS_BALCAO[0]


## Cozinhando: balança, mexe a panela, sai vapor e a barra enche.
func _animar(c: Node2D) -> void:
	var barra: ProgressBar = c.get_node("Barra")
	var panela: Sprite2D = c.get_node("Panela")
	var icone: Sprite2D = c.get_node("Prato")
	var corpo: Sprite2D = c.get_node("Corpo")
	if _trabalho.has(c):
		var p: Dictionary = _trabalho[c]
		barra.visible = true
		barra.value = p["feito"] / p["tempo"] * 100.0
		icone.visible = true
		icone.texture = Estado.textura(p["comida"])
		c.get_node("Vapor").emitting = true
		corpo.rotation = sin(_tempo * 9.0) * 0.1               # mexendo a panela
		panela.rotation = sin(_tempo * 9.0 + 1.0) * 0.15
		panela.position.x = sin(_tempo * 9.0) * 4.0
	else:
		barra.visible = false
		icone.visible = false
		c.get_node("Vapor").emitting = false
		corpo.rotation = sin(_tempo * 2.0) * 0.04             # esperando
		panela.rotation = 0.0
	# Pratos prontos: o sininho balança.
	for p in pedidos:
		if p["estado"] == "pronto":
			p["prato"].get_node("Sino").rotation = sin(_tempo * 10.0) * 0.4


## Mostra os pedidos que estão esperando na fila (no máximo 3 tickets e "+N").
func _mostrar_tickets() -> void:
	var fila := pedidos.filter(func(p): return p["estado"] == "fila")
	for i in FILA_VISIVEL:
		var t: Sprite2D = tickets.get_node("T%d" % (i + 1))
		t.visible = i < fila.size()
		if t.visible:
			t.get_node("Comida").texture = Estado.textura(fila[i]["comida"])
	var mais: Label = tickets.get_node("Mais")
	mais.visible = fila.size() > FILA_VISIVEL
	mais.text = "+%d" % (fila.size() - FILA_VISIVEL)
