extends Control
## Usado pelas telas que têm um botão "VOLTAR" para o título.


func _ready() -> void:
	var botao: Button = find_child("BotaoVoltar", true, false)
	botao.pressed.connect(_on_voltar)
	botao.grab_focus()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		_on_voltar()


func _on_voltar() -> void:
	get_tree().change_scene_to_file("res://scenes/titulo.tscn")
