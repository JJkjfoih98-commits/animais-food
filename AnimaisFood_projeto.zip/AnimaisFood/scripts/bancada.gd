extends Node2D
## A BANCADA com tábua: o cozinheiro corta e monta (salada, sushi, suco, sanduíche).
## Os ingredientes ficam na tábua e vão diminuindo enquanto o prato aparece.

const TAMANHO := Vector2(80, 50)
const PONTO := Vector2(108, 56)   # onde o cozinheiro fica de pé

var comida := ""                  # o prato sendo montado
var ingredientes: Array = []      # imagens dos ingredientes em cima da tábua
var progresso := 0.0


func ponto() -> Vector2:
	return global_position + PONTO


func _process(_delta: float) -> void:
	queue_redraw()


func _draw() -> void:
	draw_rect(Rect2(Vector2(4, 6), TAMANHO), Color(0, 0, 0, 0.15))
	draw_rect(Rect2(Vector2.ZERO, TAMANHO), Color(0.72, 0.5, 0.3))           # mesa de madeira
	draw_rect(Rect2(Vector2(0, 0), Vector2(TAMANHO.x, 8)), Color(0.82, 0.6, 0.38))
	draw_rect(Rect2(Vector2(10, 12), Vector2(60, 30)), Color(0.93, 0.8, 0.6))   # tábua
	draw_rect(Rect2(Vector2(10, 12), Vector2(60, 30)), Color(0.6, 0.42, 0.25), false, 2.0)
	if comida == "":
		return
	# Ingredientes encolhendo (estão sendo cortados)...
	var tam_ing := 18.0 * (1.0 - progresso)
	for i in ingredientes.size():
		if tam_ing > 2.0:
			draw_texture_rect(Estado.textura(ingredientes[i]), Rect2(Vector2(14 + i * 18, 18), Vector2(tam_ing, tam_ing)), false)
	# ...e o prato aparecendo
	var tam := 26.0 * progresso
	if tam > 2.0:
		draw_texture_rect(Estado.textura(comida), Rect2(Vector2(40 - tam / 2.0, 27 - tam / 2.0), Vector2(tam, tam)), false)
