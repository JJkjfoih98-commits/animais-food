extends Node
## ESTADO DO JOGO (autoload "Estado": existe o tempo todo, em todas as telas)
## Guarda o progresso do jogador e salva/carrega do disco:
##   dinheiro, nível e XP do restaurante, estrelas de cada fase e melhorias.
## As tabelas (comidas, fases, missões) ficam em scripts/dados.gd.

const Dados = preload("res://scripts/dados.gd")

const DINHEIRO_INICIAL := 150
const REPUTACAO_MAX := 5.0
const ARQUIVO_SAVE := "user://progresso.cfg"

var dinheiro := DINHEIRO_INICIAL
var nivel := 1                  # nível do restaurante (sobe com XP)
var xp := 0                     # XP juntado dentro do nível atual
var estrelas_fase := {}         # número da fase -> estrelas ganhas (0 a 3)
var melhorias := {"cadeiras": 0, "cardapio": 0, "fogao": 0, "ajudante": 0}
var som_ligado := true
var visao_toto := false   # modo câmera seguindo o Totó (lembra a escolha)

## Fase que está sendo jogada agora (1 a 10).
var fase := 1

# Resultado da última fase (preenchido pela cena do jogo, mostrado no Fim do Dia)
var ultimo_atendidos := 0
var ultimo_ganho := 0
var ultima_avaliacao := 0.0
var ultimas_missoes: Array = []   # [{texto, ok, dinheiro, xp}, ...]
var ultimas_estrelas := 0


func _ready() -> void:
	carregar()


# ------------------------------------------------------------------ progresso

func novo_jogo() -> void:
	dinheiro = DINHEIRO_INICIAL
	nivel = 1
	xp = 0
	estrelas_fase = {}
	melhorias = {"cadeiras": 0, "cardapio": 0, "fogao": 0, "ajudante": 0}
	fase = 1
	salvar()


func tem_progresso() -> bool:
	return nivel > 1 or xp > 0 or not estrelas_fase.is_empty()


## Uma fase está liberada se for a primeira ou se a anterior tiver 1 estrela ou mais.
func fase_liberada(n: int) -> bool:
	return n == 1 or estrelas_fase.get(n - 1, 0) >= 1


func dados_fase(n: int = fase) -> Dictionary:
	return Dados.FASES[clampi(n, 1, Dados.FASES.size()) - 1]


## Comidas que o restaurante já sabe fazer (pelo nível).
func comidas_liberadas() -> Array:
	var lista := []
	for id in Dados.COMIDAS:
		if Dados.COMIDAS[id]["nivel"] <= nivel:
			lista.append(id)
	return lista


func xp_para_subir() -> int:
	return Dados.xp_para_subir(nivel)


## Soma XP. Se subir de nível, devolve a lista de comidas novas liberadas.
func ganhar_xp(qtd: int) -> Array:
	var novas := []
	xp += qtd
	while nivel < Dados.NIVEL_MAX and xp >= xp_para_subir():
		xp -= xp_para_subir()
		nivel += 1
		for id in Dados.COMIDAS:
			if Dados.COMIDAS[id]["nivel"] == nivel:
				novas.append(id)
	if nivel >= Dados.NIVEL_MAX:
		xp = mini(xp, xp_para_subir())
	return novas


# ------------------------------------------------------------------ regras que dependem das melhorias

## Segundos que um cliente espera nesta fase (Cadeiras fofinhas aumentam).
func paciencia() -> float:
	return dados_fase()["paciencia"] * (1.0 + 0.2 * melhorias["cadeiras"])


## Segundos que o chef leva para fazer uma comida (Fogão turbo diminui).
func tempo_preparo(comida: String) -> float:
	return Dados.COMIDAS[comida]["preparo"] / (1.0 + 0.2 * melhorias["fogao"])


func preco(comida: String) -> int:
	return Dados.COMIDAS[comida]["preco"] + 3 * melhorias["cardapio"]


func preco_melhoria(id: String) -> int:
	return Dados.MELHORIAS[id]["preco"] * (melhorias[id] + 1)


func comprar_melhoria(id: String) -> bool:
	if melhorias[id] >= Dados.MELHORIAS[id]["max"] or dinheiro < preco_melhoria(id):
		return false
	dinheiro -= preco_melhoria(id)
	melhorias[id] += 1
	salvar()
	return true


## Imagens já carregadas ficam guardadas aqui. Isso deixa o jogo mais rápido e,
## importante: quem desenha com _draw() precisa que a imagem continue na memória
## até ela aparecer na tela (senão aparece um quadrado branco).
var _texturas := {}

func textura(nome: String) -> Texture2D:
	if not _texturas.has(nome):
		_texturas[nome] = load("res://assets/images/%s.png" % nome)
	return _texturas[nome]


# ------------------------------------------------------------------ salvar / carregar

func salvar() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("jogo", "dinheiro", dinheiro)
	cfg.set_value("jogo", "nivel", nivel)
	cfg.set_value("jogo", "xp", xp)
	cfg.set_value("jogo", "estrelas_fase", estrelas_fase)
	cfg.set_value("jogo", "melhorias", melhorias)
	cfg.set_value("opcoes", "som", som_ligado)
	cfg.set_value("opcoes", "visao_toto", visao_toto)
	if cfg.save(ARQUIVO_SAVE) != OK:
		push_warning("Não consegui salvar o progresso")


func carregar() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(ARQUIVO_SAVE) != OK:
		return  # primeira vez jogando
	dinheiro = int(cfg.get_value("jogo", "dinheiro", DINHEIRO_INICIAL))
	nivel = clampi(int(cfg.get_value("jogo", "nivel", 1)), 1, Dados.NIVEL_MAX)
	xp = maxi(0, int(cfg.get_value("jogo", "xp", 0)))
	var e = cfg.get_value("jogo", "estrelas_fase", {})
	estrelas_fase = {}
	if e is Dictionary:
		for k in e:
			estrelas_fase[int(k)] = clampi(int(e[k]), 0, 3)
	var m = cfg.get_value("jogo", "melhorias", {})
	for id in melhorias:
		if m is Dictionary and m.has(id):
			melhorias[id] = clampi(int(m[id]), 0, Dados.MELHORIAS[id]["max"])
	som_ligado = bool(cfg.get_value("opcoes", "som", true))
	visao_toto = bool(cfg.get_value("opcoes", "visao_toto", false))
