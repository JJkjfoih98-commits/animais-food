extends Node
## Estado global do jogo (autoload "Estado"): dinheiro, dia, melhorias e
## resultado do último dia. Também guarda os dados das comidas e animais.

const COMIDAS := {
	"suco": {"nome": "Suco", "preco": 8},
	"cupcake": {"nome": "Cupcake", "preco": 10},
	"bolo": {"nome": "Bolo", "preco": 12},
	"hamburguer": {"nome": "Hambúrguer", "preco": 15},
	"pizza": {"nome": "Pizza", "preco": 18},
}
## Ordem em que as comidas vão sendo liberadas nos dias.
const ORDEM_COMIDAS := ["suco", "cupcake", "bolo", "hamburguer", "pizza"]
const ANIMAIS := ["coelho", "macaco", "pinguim", "leao", "tartaruga", "urso", "gato", "cachorro"]

const DINHEIRO_INICIAL := 150
const DURACAO_DIA := 85.0  # 01:25
const REPUTACAO_MAX := 5.0

const MELHORIAS := {
	"cadeiras": {"nome": "Cadeiras fofinhas", "desc": "Clientes esperam 20% mais", "preco": 80},
	"cardapio": {"nome": "Cardápio caprichado", "desc": "+$3 em cada pedido", "preco": 100},
}
const NIVEL_MAX_MELHORIA := 3

var dia := 1
var dinheiro := DINHEIRO_INICIAL
var melhorias := {"cadeiras": 0, "cardapio": 0}
var som_ligado := true
## Dia que será jogado ao abrir o jogo de novo.
var dia_salvo := 1

# Resultado do último dia (preenchido pela cena do jogo).
var ultimo_atendidos := 0
var ultimo_ganho := 0
var ultima_avaliacao := 0.0


const ARQUIVO_SAVE := "user://progresso.cfg"


func _ready() -> void:
	carregar()


func novo_jogo() -> void:
	dia = 1
	dia_salvo = 1
	dinheiro = DINHEIRO_INICIAL
	melhorias = {"cadeiras": 0, "cardapio": 0}
	salvar()


func tem_progresso() -> bool:
	return dia_salvo > 1 or dinheiro != DINHEIRO_INICIAL


func salvar() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("jogo", "dia", dia_salvo)
	cfg.set_value("jogo", "dinheiro", dinheiro)
	cfg.set_value("jogo", "melhorias", melhorias)
	cfg.set_value("opcoes", "som", som_ligado)
	var err := cfg.save(ARQUIVO_SAVE)
	if err != OK:
		push_warning("Não consegui salvar o progresso (erro %d)" % err)


func carregar() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(ARQUIVO_SAVE) != OK:
		return  # primeira vez jogando
	dia_salvo = maxi(1, int(cfg.get_value("jogo", "dia", 1)))
	dia = dia_salvo
	dinheiro = int(cfg.get_value("jogo", "dinheiro", DINHEIRO_INICIAL))
	var m = cfg.get_value("jogo", "melhorias", {})
	for id in melhorias:
		if m is Dictionary and m.has(id):
			melhorias[id] = clampi(int(m[id]), 0, NIVEL_MAX_MELHORIA)
	som_ligado = bool(cfg.get_value("opcoes", "som", true))


func comidas_do_dia() -> Array:
	return ORDEM_COMIDAS.slice(0, mini(ORDEM_COMIDAS.size(), 2 + dia))


## Segundos que um cliente espera pelo pedido.
func paciencia_do_dia() -> float:
	var base := maxf(9.0, 22.0 - 2.0 * (dia - 1))
	return base * (1.0 + 0.2 * melhorias["cadeiras"])


## Segundos entre a chegada de um cliente e outro.
func intervalo_clientes() -> float:
	return maxf(1.5, 5.0 - 0.6 * (dia - 1))


func bonus_por_pedido() -> int:
	return 3 * melhorias["cardapio"]


func preco_melhoria(id: String) -> int:
	return MELHORIAS[id]["preco"] * (melhorias[id] + 1)


func comprar_melhoria(id: String) -> bool:
	if melhorias[id] >= NIVEL_MAX_MELHORIA or dinheiro < preco_melhoria(id):
		return false
	dinheiro -= preco_melhoria(id)
	melhorias[id] += 1
	salvar()
	return true


func textura(nome: String) -> Texture2D:
	return load("res://assets/images/%s.png" % nome)
