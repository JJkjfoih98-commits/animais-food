extends Node
## Autoload "Som": música de fundo em loop, efeitos e ligar/desligar o som.
## Todo botão do jogo toca "clique" automaticamente.
## Se o aparelho não tiver saída de áudio, o Godot usa um driver mudo e
## nada disto dá erro.

const EFEITOS := ["cliente_chega", "moeda", "erro", "cliente_bravo", "clique", "fim_do_dia", "pegar", "passo"]
## Volume de cada som em decibéis (0 = normal, negativo = mais baixo).
const VOLUME := {"passo": -14.0, "clique": -4.0}
const VOZES := 6

var ligado: bool:
	get:
		return Estado.som_ligado
var _sons := {}
var _vozes: Array[AudioStreamPlayer] = []
var _proxima := 0
var _musica: AudioStreamPlayer


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for nome in EFEITOS:
		_sons[nome] = load("res://assets/sounds/%s.wav" % nome)
	for i in VOZES:
		var p := AudioStreamPlayer.new()
		add_child(p)
		_vozes.append(p)
	_musica = AudioStreamPlayer.new()
	_musica.stream = load("res://assets/sounds/musica_fundo.wav")
	_musica.volume_db = -8.0
	_musica.finished.connect(_musica.play)  # loop
	add_child(_musica)
	_musica.play()
	get_tree().node_added.connect(_on_node_added)
	aplicar()


func tocar(nome: String) -> void:
	if not ligado or not _sons.has(nome):
		return
	var p := _vozes[_proxima]
	_proxima = (_proxima + 1) % VOZES
	p.stream = _sons[nome]
	p.volume_db = VOLUME.get(nome, 0.0)
	p.play()


func alternar() -> void:
	Estado.som_ligado = not Estado.som_ligado
	aplicar()
	Estado.salvar()


func aplicar() -> void:
	AudioServer.set_bus_mute(0, not ligado)


func _on_node_added(n: Node) -> void:
	if n is BaseButton:
		n.pressed.connect(tocar.bind("clique"))
