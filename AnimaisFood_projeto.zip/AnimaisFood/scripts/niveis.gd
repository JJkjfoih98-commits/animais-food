extends Control
## MAPA DAS FASES
## Mostra as 10 fases. Cada fase mostra as estrelas ganhas (0 a 3).
## Uma fase abre quando a anterior tem pelo menos 1 estrela.

const Dados = preload("res://scripts/dados.gd")


func _ready() -> void:
	%Info.text = "Restaurante nível %d   ·   $%d   ·   %d comidas no cardápio" % [
		Estado.nivel, Estado.dinheiro, Estado.comidas_liberadas().size()]
	%BarraXP.max_value = Estado.xp_para_subir()
	%BarraXP.value = Estado.xp
	%Voltar.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/titulo.tscn"))
	for n in range(1, Dados.FASES.size() + 1):
		%Fases.add_child(_botao_fase(n))


func _botao_fase(n: int) -> Button:
	var b := Button.new()
	b.name = "Fase%d" % n
	b.custom_minimum_size = Vector2(200, 150)
	var liberada := Estado.fase_liberada(n)
	b.disabled = not liberada
	b.pressed.connect(func():
		Estado.fase = n
		get_tree().change_scene_to_file("res://scenes/jogo.tscn"))
	# Conteúdo do botão: número da fase e as estrelas (ou um cadeado).
	var caixa := VBoxContainer.new()
	caixa.set_anchors_preset(Control.PRESET_FULL_RECT)
	caixa.alignment = BoxContainer.ALIGNMENT_CENTER
	caixa.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var titulo := Label.new()
	titulo.text = "FASE %d" % n
	titulo.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	titulo.add_theme_font_size_override("font_size", 30)
	caixa.add_child(titulo)
	var linha := HBoxContainer.new()
	linha.alignment = BoxContainer.ALIGNMENT_CENTER
	linha.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if liberada:
		var ganhas: int = Estado.estrelas_fase.get(n, 0)
		for i in 3:
			linha.add_child(_icone("estrela", 1.0 if i < ganhas else 0.25))
	else:
		linha.add_child(_icone("cadeado", 1.0))
	caixa.add_child(linha)
	b.add_child(caixa)
	return b


func _icone(nome: String, brilho: float) -> TextureRect:
	var t := TextureRect.new()
	t.texture = Estado.textura(nome)
	t.custom_minimum_size = Vector2(44, 44)
	t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	t.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	t.mouse_filter = Control.MOUSE_FILTER_IGNORE
	t.modulate = Color(1, 1, 1, brilho) if brilho >= 1.0 else Color(0.2, 0.2, 0.2, 0.4)
	return t
