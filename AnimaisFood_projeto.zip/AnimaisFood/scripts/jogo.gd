extends Node2D
## O RESTAURANTE (pátio visto de cima) - o script principal de uma fase.
## Ele cuida de:
##   1) mostrar as missões no começo e chamar clientes para as mesas;
##   2) mandar cada pedido para a cozinha (scripts/cozinha.gd);
##   3) o Totó pegar o prato pronto no balcão e entregar na mesa (botão AÇÃO);
##   4) dinheiro, estrelas de reputação, XP e nível do restaurante;
##   5) avisar as missões (scripts/missoes.gd) e terminar o dia.

const Dados = preload("res://scripts/dados.gd")

const DISTANCIA_PEGAR := 110.0    # quão perto do prato o Totó precisa estar
const DISTANCIA_ENTREGAR := 130.0 # quão perto da mesa

var tempo_restante := 90.0
var reputacao := Estado.REPUTACAO_MAX
var atendidos := 0
var ganho := 0
var acabou := false
var comecou := false        # o dia só começa depois de apertar COMEÇAR
var _proximo_cliente := 1.0
var _dono_do_prato = null   # mesa para a qual o prato na mão do Totó foi feito
var _dinheiro_inicio := Estado.dinheiro
var _alvo := {}             # o que o Totó pode pegar/entregar agora
var _avisos: Array = []     # avisos esperando para aparecer (missão, nível)

@onready var garcom = $Patio/Garcom
@onready var cozinha = $Cozinha
@onready var missoes = $Missoes
@onready var mesas: Array = []
@onready var botao_acao: TouchScreenButton = $Controles/BotaoAcao
@onready var texto_acao: Label = $Controles/TextoAcao
@onready var pausa: Control = $HUD/Pausa


func _ready() -> void:
	var fase: Dictionary = Estado.dados_fase()
	tempo_restante = fase["duracao"]
	garcom.joystick = $Controles/Joystick
	# Quantas mesas esta fase tem: as outras somem.
	for m in $Patio/Mesas.get_children():
		if m.numero <= fase["mesas"]:
			mesas.append(m)
			m.paciencia_esgotada.connect(_on_paciencia_esgotada)
		else:
			m.queue_free()
	# 5 estrelas da reputação no HUD
	for i in 5:
		var e := TextureRect.new()
		e.texture = Estado.textura("estrela")
		e.custom_minimum_size = Vector2(26, 26)
		e.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		e.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		%Estrelas.add_child(e)
	# Missões
	missoes.preparar(fase["missoes"])
	missoes.cumprida.connect(_on_missao_cumprida)
	_montar_painel_missoes()
	_montar_tela_inicio()
	# Pausa (engrenagem)
	%BotaoEngrenagem.pressed.connect(_abrir_pausa)
	%Continuar.pressed.connect(_fechar_pausa)
	%BotaoSom.pressed.connect(func():
		Som.alternar()
		_texto_som())
	%Reiniciar.pressed.connect(func():
		Estado.dinheiro = _dinheiro_inicio
		get_tree().paused = false
		get_tree().reload_current_scene())
	%Menu.pressed.connect(func():
		get_tree().paused = false
		get_tree().change_scene_to_file("res://scenes/niveis.tscn"))
	_texto_som()
	pausa.visible = false
	_atualizar_hud()


# ------------------------------------------------------------------ começo do dia

## Tela de começo: mostra a fase e as 3 missões. O jogo fica parado até COMEÇAR.
func _montar_tela_inicio() -> void:
	%TituloInicio.text = "FASE %d" % Estado.fase
	var texto := ""
	for m in missoes.lista:
		texto += "- " + m["texto"] + "\n"
	%MissoesInicio.text = texto
	%Comecar.pressed.connect(comecar)
	%Inicio.visible = true
	get_tree().paused = true


func comecar() -> void:
	%Inicio.visible = false
	get_tree().paused = false
	comecou = true


# ------------------------------------------------------------------ a cada quadro

func _process(delta: float) -> void:
	if acabou or not comecou:
		return
	# Relógio do dia
	tempo_restante -= delta
	if tempo_restante <= 0.0:
		tempo_restante = 0.0
		_atualizar_hud()
		_fim_do_dia("FIM DO DIA!")
		return
	# Chegada de clientes
	_proximo_cliente -= delta
	if _proximo_cliente <= 0.0:
		_chamar_cliente()
	# O que o Totó pode fazer agora? (mostra a dica e acende o botão)
	_alvo = _procurar_alvo()
	_mostrar_alvo()
	if Input.is_action_just_pressed("acao"):
		usar_acao()
	_atualizar_hud()


## Coloca um cliente novo numa mesa vazia e manda o pedido para a cozinha.
func _chamar_cliente() -> void:
	_proximo_cliente = Estado.dados_fase()["intervalo"]
	var livres := mesas.filter(func(m): return m.esta_livre())
	if livres.is_empty():
		_proximo_cliente = 1.0
		return
	var mesa = livres.pick_random()
	var comida: String = Estado.comidas_liberadas().pick_random()
	# Se uma missão pede uma comida, os clientes pedem ela mais vezes.
	if missoes.comida_da_missao() != "" and randf() < 0.35:
		comida = missoes.comida_da_missao()
	mesa.chegar(Dados.ANIMAIS.pick_random(), comida, Estado.paciencia())
	cozinha.novo_pedido(mesa, comida)


## Procura o que está perto do Totó: um prato pronto no balcão ou uma mesa.
func _procurar_alvo() -> Dictionary:
	var pos: Vector2 = garcom.global_position
	var prato: Dictionary = cozinha.prato_perto(pos, DISTANCIA_PEGAR)
	if not prato.is_empty():
		return {"tipo": "prato", "pedido": prato}
	var melhor := {}
	var menor := DISTANCIA_ENTREGAR
	for m in mesas:
		var d: float = pos.distance_to(m.global_position)
		if m.esta_esperando() and d < menor:
			menor = d
			melhor = {"tipo": "mesa", "mesa": m}
	return melhor


func _mostrar_alvo() -> void:
	var texto := ""
	if _alvo.get("tipo") == "prato":
		texto = "PEGAR " + Dados.COMIDAS[_alvo["pedido"]["comida"]]["nome"].to_upper()
	elif _alvo.get("tipo") == "mesa":
		texto = "ENTREGAR" if garcom.prato != "" else "Espere o prato no balcão!"
	garcom.mostrar_dica(texto)
	texto_acao.text = texto if texto != "" and not texto.begins_with("Espere") else "AÇÃO"
	botao_acao.modulate = Color.WHITE if texto != "" else Color(1, 1, 1, 0.55)


## O jogador apertou AÇÃO (Espaço, E, Enter ou o botão redondo da tela).
func usar_acao() -> void:
	if acabou or _alvo.is_empty():
		return
	if _alvo["tipo"] == "prato":
		if garcom.prato != "":
			return  # já está com um prato na mão
		var pedido: Dictionary = _alvo["pedido"]
		garcom.pegar(pedido["comida"])
		_dono_do_prato = pedido["mesa"]
		cozinha.retirar(pedido)
		Som.tocar("pegar")
	elif _alvo["tipo"] == "mesa" and garcom.prato != "":
		_entregar(_alvo["mesa"])


## Entrega o prato que o Totó está carregando na mesa.
func _entregar(mesa) -> void:
	var fracao: float = mesa.fracao_paciencia()
	var comida: String = garcom.prato
	var espera: float = mesa.esperando_ha
	if mesa.servir(comida):
		# Certo! Preço + gorjeta pela paciência que sobrou.
		var valor: int = Estado.preco(comida) + int(round(10.0 * fracao))
		Estado.dinheiro += valor
		ganho += valor
		atendidos += 1
		if fracao > 0.6:  # entregou rápido: recupera um pouquinho de estrela
			reputacao = minf(Estado.REPUTACAO_MAX, reputacao + 0.25)
		# Se o prato era de outra mesa (mesma comida), o pedido desta mesa passa pra lá.
		if _dono_do_prato != mesa and is_instance_valid(_dono_do_prato):
			cozinha.trocar_dono(_dono_do_prato, mesa)
		else:
			cozinha.cancelar(mesa)
		garcom.soltar()
		_dono_do_prato = null
		_mensagem(mesa.global_position, "+$%d" % valor, Color(0.1, 0.6, 0.1))
		Som.tocar("moeda")
		_ganhar_xp(Dados.XP_POR_ENTREGA)
		missoes.entregou(comida, espera, valor)
	else:
		# Errado: perde meia estrela (o Totó continua com o prato na mão).
		_perder_reputacao(0.5)
		missoes.errou()
		_mensagem(mesa.global_position, "Não pedi isso!", Color(0.85, 0.1, 0.1))
		Som.tocar("erro")
	_atualizar_hud()


func _on_paciencia_esgotada(mesa) -> void:
	cozinha.cancelar(mesa)
	missoes.cliente_bravo()
	_mensagem(mesa.global_position, "Demorou demais!", Color(0.85, 0.1, 0.1))
	Som.tocar("cliente_bravo")
	_perder_reputacao(1.0)


func _perder_reputacao(qtd: float) -> void:
	reputacao = maxf(0.0, reputacao - qtd)
	_atualizar_hud()
	if reputacao <= 0.0:
		_fim_do_dia("O restaurante fechou mais cedo...")


# ------------------------------------------------------------------ XP e missões

func _ganhar_xp(qtd: int) -> void:
	var nivel_antes := Estado.nivel
	var novas: Array = Estado.ganhar_xp(qtd)
	if Estado.nivel > nivel_antes:
		var nomes := ", ".join(novas.map(func(c): return Dados.COMIDAS[c]["nome"]))
		_aviso("NÍVEL %d!" % Estado.nivel, ("Novas comidas: " + nomes) if nomes != "" else "", "nivel", "trofeu")


func _on_missao_cumprida(m: Dictionary) -> void:
	Estado.dinheiro += m["dados"]["dinheiro"]
	_aviso("MISSÃO CUMPRIDA!", "%s  (+$%d, +%d XP)" % [m["texto"], m["dados"]["dinheiro"], m["dados"]["xp"]], "missao", "festa")
	_ganhar_xp(m["dados"]["xp"])
	_montar_painel_missoes()


## Faixa grande no meio de cima da tela (some sozinha depois de 2,5 s).
func _aviso(titulo: String, texto: String, som: String, icone: String) -> void:
	_avisos.append([titulo, texto, som, icone])
	if _avisos.size() == 1:
		_mostrar_proximo_aviso()


func _mostrar_proximo_aviso() -> void:
	if _avisos.is_empty():
		return
	var a: Array = _avisos[0]
	%AvisoTitulo.text = a[0]
	%AvisoTexto.text = a[1]
	%AvisoIcone.texture = Estado.textura(a[3])
	Som.tocar(a[2])
	var faixa: Control = %Faixa
	faixa.visible = true
	faixa.modulate.a = 0.0
	var t := create_tween()
	t.tween_property(faixa, "modulate:a", 1.0, 0.2)
	t.tween_interval(2.3)
	t.tween_property(faixa, "modulate:a", 0.0, 0.3)
	t.tween_callback(func():
		faixa.visible = false
		_avisos.pop_front()
		_mostrar_proximo_aviso())


# ------------------------------------------------------------------ HUD

func _atualizar_hud() -> void:
	%ValorDinheiro.text = "$%d" % Estado.dinheiro
	var s := int(ceil(tempo_restante))
	%ValorTempo.text = "%02d:%02d" % [s / 60, s % 60]
	%ValorTempo.modulate = Color(1, 0.3, 0.3) if s <= 10 else Color.WHITE
	var meias := roundf(reputacao * 2.0) / 2.0  # arredonda para meia estrela
	for i in %Estrelas.get_child_count():
		var e: TextureRect = %Estrelas.get_child(i)
		if meias >= i + 1:
			e.modulate = Color.WHITE
		elif meias >= i + 0.5:
			e.modulate = Color(1, 1, 1, 0.5)
		else:
			e.modulate = Color(0.2, 0.2, 0.2, 0.35)
	%Nivel.text = "NÍVEL %d  ·  FASE %d" % [Estado.nivel, Estado.fase]
	%BarraXP.max_value = Estado.xp_para_subir()
	%BarraXP.value = Estado.xp
	%Atendidos.text = "Atendidos: %d   Combo: %d" % [atendidos, missoes.combo]
	for i in missoes.lista.size():
		var linha: Label = %ListaMissoes.get_child(i).get_child(1)
		var m: Dictionary = missoes.lista[i]
		linha.text = "%s  [%s]" % [m["texto"], missoes.progresso(m)]


## Painel de missões (canto direito): um ícone (certo/vazio) e o texto.
func _montar_painel_missoes() -> void:
	for c in %ListaMissoes.get_children():
		c.queue_free()
		%ListaMissoes.remove_child(c)
	for m in missoes.lista:
		var linha := HBoxContainer.new()
		var icone := TextureRect.new()
		icone.texture = Estado.textura("certo" if m["ok"] else "ticket")
		icone.custom_minimum_size = Vector2(22, 22)
		icone.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icone.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		var texto := Label.new()
		texto.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		texto.custom_minimum_size = Vector2(150, 0)
		texto.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		texto.add_theme_font_size_override("font_size", 14)
		texto.add_theme_color_override("font_color", Color(0.1, 0.5, 0.1) if m["ok"] else Color(0.3, 0.18, 0.08))
		linha.add_child(icone)
		linha.add_child(texto)
		%ListaMissoes.add_child(linha)


## Texto que sobe e some (ex.: "+$20") em cima de uma mesa.
func _mensagem(pos: Vector2, texto: String, cor: Color) -> void:
	var l := Label.new()
	l.text = texto
	l.z_index = 30
	l.add_theme_font_size_override("font_size", 30)
	l.add_theme_color_override("font_color", cor)
	l.add_theme_color_override("font_outline_color", Color.WHITE)
	l.add_theme_constant_override("outline_size", 8)
	l.size = Vector2(260, 40)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.position = pos + Vector2(-130, -150)
	add_child(l)
	var t := create_tween()
	t.tween_property(l, "position:y", l.position.y - 70, 1.0)
	t.parallel().tween_property(l, "modulate:a", 0.0, 1.0).set_delay(0.4)
	t.tween_callback(l.queue_free)


# ------------------------------------------------------------------ fim e pausa

func _fim_do_dia(texto: String) -> void:
	if acabou:
		return
	acabou = true
	missoes.fim_do_dia(reputacao)
	# Guarda o resultado para a tela de Fim do Dia.
	Estado.ultimo_atendidos = atendidos
	Estado.ultimo_ganho = ganho
	Estado.ultima_avaliacao = roundf(reputacao * 2.0) / 2.0
	Estado.ultimas_missoes = missoes.lista.map(func(m): return {"texto": m["texto"], "ok": m["ok"],
		"dinheiro": m["dados"]["dinheiro"], "xp": m["dados"]["xp"]})
	Estado.ultimas_estrelas = missoes.estrelas()
	# Estrelas da fase: guarda a melhor marca.
	Estado.estrelas_fase[Estado.fase] = maxi(Estado.estrelas_fase.get(Estado.fase, 0), missoes.estrelas())
	Estado.salvar()
	Som.tocar("fim_do_dia")
	%Aviso.text = texto
	%Aviso.visible = true
	garcom.set_physics_process(false)
	cozinha.set_process(false)
	for m in mesas:
		m.set_process(false)
	await get_tree().create_timer(1.8).timeout
	get_tree().change_scene_to_file("res://scenes/fim_do_dia.tscn")


func _texto_som() -> void:
	%BotaoSom.text = "SOM: LIGADO" if Estado.som_ligado else "SOM: DESLIGADO"


func _abrir_pausa() -> void:
	if acabou or not comecou:
		return
	pausa.visible = true
	get_tree().paused = true


func _fechar_pausa() -> void:
	pausa.visible = false
	get_tree().paused = false


# ------------------------------------------------------------------ chão

## Desenha o chão: azulejos na cozinha, fogão e lajotas no pátio com cerca viva.
func _draw() -> void:
	# Cozinha (esquerda): azulejo xadrez
	for x in range(0, 300, 50):
		for y in range(70, 720, 50):
			var claro := (x / 50 + y / 50) % 2 == 0
			draw_rect(Rect2(x, y, 50, 50), Color(0.93, 0.94, 0.96) if claro else Color(0.82, 0.85, 0.9))
	# Fogão com 4 bocas (as panelas são desenhos à parte, nos cozinheiros)
	draw_rect(Rect2(12, 318, 202, 96), Color(0.35, 0.36, 0.4))
	draw_rect(Rect2(18, 324, 190, 84), Color(0.45, 0.46, 0.5))
	for boca in [Vector2(50, 348), Vector2(110, 348), Vector2(170, 348), Vector2(50, 388), Vector2(110, 388), Vector2(170, 388)]:
		draw_circle(boca, 13, Color(0.2, 0.2, 0.22))
		draw_arc(boca, 9, 0, TAU, 20, Color(1, 0.45, 0.15), 3.0)
	# Placa da fila do chef
	draw_rect(Rect2(10, 80, 205, 86), Color(1, 0.98, 0.9))
	draw_rect(Rect2(10, 80, 205, 86), Color(0.55, 0.25, 0.12), false, 3.0)
	# Pátio: lajotas cor de terracota
	draw_rect(Rect2(300, 70, 980, 650), Color(0.93, 0.78, 0.6))
	for x in range(300, 1280, 70):
		for y in range(70, 720, 70):
			if (x / 70 + y / 70) % 2 == 0:
				draw_rect(Rect2(x + 2, y + 2, 66, 66), Color(0.96, 0.84, 0.68))
	# Cerca viva (grama) em cima e embaixo
	draw_rect(Rect2(300, 70, 980, 44), Color(0.45, 0.72, 0.35))
	draw_rect(Rect2(300, 700, 980, 20), Color(0.45, 0.72, 0.35))
	for x in range(310, 1280, 40):
		draw_circle(Vector2(x, 108), 22, Color(0.36, 0.62, 0.28))
