extends Node2D
## O RESTAURANTE (pátio visto de cima) - o script principal do jogo.
## Ele cuida de:
##   1) chamar clientes para as mesas vazias;
##   2) pegar pratos no balcão e entregar nas mesas (botão AÇÃO);
##   3) tempo do dia, dinheiro e reputação (estrelas);
##   4) o HUD (painel de cima), a lista de PEDIDOS e a pausa.

const DISTANCIA_PEGAR := 110.0    # quão perto do prato o Totó precisa estar
const DISTANCIA_ENTREGAR := 130.0 # quão perto da mesa
const ESPACO_PRATOS := 105.0      # distância entre um prato e outro no balcão

var tempo_restante := Estado.DURACAO_DIA
var reputacao := Estado.REPUTACAO_MAX
var atendidos := 0
var ganho := 0
var acabou := false
var pratos := {}            # comida -> nó do prato no balcão
var _proximo_cliente := 1.0
var _linhas_pedido := {}    # mesa -> linha na lista de PEDIDOS
var _dinheiro_inicio := Estado.dinheiro
var _alvo := {}             # o que o Totó pode pegar/entregar agora

@onready var garcom = $Patio/Garcom
@onready var mesas: Array = $Patio/Mesas.get_children()
@onready var chef: Node2D = $Cozinha/Chef
@onready var botao_acao: TouchScreenButton = $Controles/BotaoAcao
@onready var texto_acao: Label = $Controles/TextoAcao
@onready var pausa: Control = $HUD/Pausa


func _ready() -> void:
	garcom.joystick = $Controles/Joystick
	%Dia.text = "DIA %d" % Estado.dia
	# 5 estrelas da reputação
	for i in 5:
		var e := TextureRect.new()
		e.texture = Estado.textura("estrela")
		e.custom_minimum_size = Vector2(30, 30)
		e.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		e.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		%Estrelas.add_child(e)
	_colocar_pratos_no_balcao()
	for m in mesas:
		m.paciencia_esgotada.connect(_on_paciencia_esgotada)
	# Pausa (engrenagem)
	%BotaoEngrenagem.pressed.connect(_abrir_pausa)
	%Continuar.pressed.connect(_fechar_pausa)
	%BotaoSom.pressed.connect(func():
		Som.alternar()
		_texto_som())
	%Reiniciar.pressed.connect(func():
		Estado.dinheiro = _dinheiro_inicio
		get_tree().paused = false
		get_tree().reload_current_scene())
	%Menu.pressed.connect(func():
		get_tree().paused = false
		get_tree().change_scene_to_file("res://scenes/titulo.tscn"))
	_texto_som()
	pausa.visible = false
	_atualizar_hud()


## Um prato para cada comida do dia, enfileirados no balcão da cozinha.
func _colocar_pratos_no_balcao() -> void:
	var lista: Array = Estado.comidas_do_dia()
	var inicio_y := 400.0 - (lista.size() - 1) * ESPACO_PRATOS / 2.0
	for i in lista.size():
		var comida: String = lista[i]
		var prato := Sprite2D.new()
		prato.texture = Estado.textura("prato")
		prato.scale = Vector2(0.36, 0.36)
		prato.position = Vector2(0, inicio_y + i * ESPACO_PRATOS)
		var c := Sprite2D.new()
		c.texture = Estado.textura(comida)
		c.scale = Vector2(0.75, 0.75)
		c.position = Vector2(0, -12)
		prato.add_child(c)
		$Cozinha/Balcao/Pratos.add_child(prato)
		pratos[comida] = prato


func _process(delta: float) -> void:
	if acabou:
		return
	# Relógio do dia
	tempo_restante -= delta
	if tempo_restante <= 0.0:
		tempo_restante = 0.0
		_atualizar_hud()
		_fim_do_dia("FIM DO DIA!")
		return
	# Chegada de clientes
	_proximo_cliente -= delta
	if _proximo_cliente <= 0.0:
		_chamar_cliente()
	# O que o Totó pode fazer agora? (mostra a dica e acende o botão)
	_alvo = _procurar_alvo()
	_mostrar_alvo()
	if Input.is_action_just_pressed("acao"):
		usar_acao()
	_animar_cozinha()
	_atualizar_hud()


## Coloca um cliente novo numa mesa vazia (se tiver).
func _chamar_cliente() -> void:
	_proximo_cliente = Estado.intervalo_clientes()
	var livres := mesas.filter(func(m): return m.esta_livre())
	if livres.is_empty():
		_proximo_cliente = 1.0
		return
	var mesa = livres.pick_random()
	var comida: String = Estado.comidas_do_dia().pick_random()
	mesa.chegar(Estado.ANIMAIS.pick_random(), comida, Estado.paciencia_do_dia())
	_adicionar_linha_pedido(mesa, comida)


## Procura o que está perto do Totó: um prato no balcão ou uma mesa esperando.
## Devolve um dicionário, por exemplo {"tipo": "prato", "comida": "pizza"}.
func _procurar_alvo() -> Dictionary:
	var pos: Vector2 = garcom.global_position
	# Perto de algum prato no balcão?
	var melhor := {}
	var menor := DISTANCIA_PEGAR
	for comida in pratos:
		var d: float = pos.distance_to(pratos[comida].global_position)
		if d < menor:
			menor = d
			melhor = {"tipo": "prato", "comida": comida}
	if not melhor.is_empty():
		return melhor
	# Perto de alguma mesa com cliente esperando?
	menor = DISTANCIA_ENTREGAR
	for m in mesas:
		var d: float = pos.distance_to(m.global_position)
		if m.esta_esperando() and d < menor:
			menor = d
			melhor = {"tipo": "mesa", "mesa": m}
	return melhor


func _mostrar_alvo() -> void:
	var texto := ""
	if _alvo.get("tipo") == "prato":
		texto = "PEGAR " + Estado.COMIDAS[_alvo["comida"]]["nome"].to_upper()
		# o prato escolhido "pula" para chamar atenção
		var p: Sprite2D = pratos[_alvo["comida"]]
		p.scale = Vector2.ONE * (0.36 + absf(sin(Time.get_ticks_msec() / 160.0)) * 0.05)
	elif _alvo.get("tipo") == "mesa":
		texto = "ENTREGAR" if garcom.prato != "" else "Pegue o prato no balcão!"
	for comida in pratos:  # os outros pratos voltam ao normal
		if _alvo.get("comida") != comida:
			pratos[comida].scale = Vector2(0.36, 0.36)
	garcom.mostrar_dica(texto)
	texto_acao.text = texto if texto != "" and not texto.begins_with("Pegue") else "AÇÃO"
	botao_acao.modulate = Color.WHITE if texto != "" else Color(1, 1, 1, 0.55)


## O jogador apertou AÇÃO (Espaço, E, Enter ou o botão redondo da tela).
func usar_acao() -> void:
	if acabou or _alvo.is_empty():
		return
	if _alvo["tipo"] == "prato":
		garcom.pegar(_alvo["comida"])
		Som.tocar("pegar")
		_chef_pula()
	elif _alvo["tipo"] == "mesa" and garcom.prato != "":
		_entregar(_alvo["mesa"])


## Entrega o prato que o Totó está carregando na mesa.
func _entregar(mesa) -> void:
	var fracao: float = mesa.fracao_paciencia()
	var comida: String = garcom.prato
	if mesa.servir(comida):
		# Certo! Preço da comida + bônus da melhoria + gorjeta pela pressa.
		var valor: int = Estado.COMIDAS[comida]["preco"] + Estado.bonus_por_pedido() + int(round(10.0 * fracao))
		Estado.dinheiro += valor
		ganho += valor
		atendidos += 1
		if fracao > 0.6:  # entregou rápido: recupera um pouquinho de estrela
			reputacao = minf(Estado.REPUTACAO_MAX, reputacao + 0.25)
		garcom.soltar()
		_remover_linha_pedido(mesa)
		_mensagem(mesa.global_position, "+$%d" % valor, Color(0.1, 0.6, 0.1))
		Som.tocar("moeda")
	else:
		# Errado: perde meia estrela (o Totó continua com o prato na mão).
		_perder_reputacao(0.5)
		_mensagem(mesa.global_position, "Não pedi isso!", Color(0.85, 0.1, 0.1))
		Som.tocar("erro")
	_atualizar_hud()


func _on_paciencia_esgotada(mesa) -> void:
	_remover_linha_pedido(mesa)
	_mensagem(mesa.global_position, "Demorou demais!", Color(0.85, 0.1, 0.1))
	Som.tocar("cliente_bravo")
	_perder_reputacao(1.0)


func _perder_reputacao(qtd: float) -> void:
	reputacao = maxf(0.0, reputacao - qtd)
	_atualizar_hud()
	if reputacao <= 0.0:
		_fim_do_dia("O restaurante fechou mais cedo...")


# ---------------------------------------------------------------- HUD

func _atualizar_hud() -> void:
	%ValorDinheiro.text = "$%d" % Estado.dinheiro
	var s := int(ceil(tempo_restante))
	%ValorTempo.text = "%02d:%02d" % [s / 60, s % 60]
	%ValorTempo.modulate = Color(1, 0.3, 0.3) if s <= 10 else Color.WHITE
	var meias := roundf(reputacao * 2.0) / 2.0  # arredonda para meia estrela
	for i in %Estrelas.get_child_count():
		var e: TextureRect = %Estrelas.get_child(i)
		if meias >= i + 1:
			e.modulate = Color.WHITE
		elif meias >= i + 0.5:
			e.modulate = Color(1, 1, 1, 0.5)
		else:
			e.modulate = Color(0.2, 0.2, 0.2, 0.35)
	%Contador.text = "%d em espera" % _linhas_pedido.size()
	%Atendidos.text = "Atendidos: %d" % atendidos


func _adicionar_linha_pedido(mesa, comida: String) -> void:
	var linha := HBoxContainer.new()
	var icone := TextureRect.new()
	icone.texture = Estado.textura(comida)
	icone.custom_minimum_size = Vector2(32, 32)
	icone.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icone.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	var texto := Label.new()
	texto.text = "%s - Mesa %d" % [Estado.COMIDAS[comida]["nome"], mesa.numero]
	texto.add_theme_color_override("font_color", Color(0.3, 0.18, 0.08))
	texto.add_theme_font_size_override("font_size", 17)
	linha.add_child(icone)
	linha.add_child(texto)
	%ListaPedidos.add_child(linha)
	_linhas_pedido[mesa] = linha


func _remover_linha_pedido(mesa) -> void:
	if _linhas_pedido.has(mesa):
		_linhas_pedido[mesa].queue_free()
		_linhas_pedido.erase(mesa)


## Texto que sobe e some (ex.: "+$20") em cima de uma mesa.
func _mensagem(pos: Vector2, texto: String, cor: Color) -> void:
	var l := Label.new()
	l.text = texto
	l.z_index = 30
	l.add_theme_font_size_override("font_size", 30)
	l.add_theme_color_override("font_color", cor)
	l.add_theme_color_override("font_outline_color", Color.WHITE)
	l.add_theme_constant_override("outline_size", 8)
	l.size = Vector2(260, 40)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.position = pos + Vector2(-130, -150)
	add_child(l)
	var t := create_tween()
	t.tween_property(l, "position:y", l.position.y - 70, 1.0)
	t.parallel().tween_property(l, "modulate:a", 0.0, 1.0).set_delay(0.4)
	t.tween_callback(l.queue_free)


# ---------------------------------------------------------------- cozinha

func _animar_cozinha() -> void:
	# O chef balança enquanto cozinha.
	chef.rotation = sin(Time.get_ticks_msec() / 300.0) * 0.05


func _chef_pula() -> void:
	var t := create_tween()
	t.tween_property(chef, "position:y", chef.position.y - 20, 0.1)
	t.tween_property(chef, "position:y", chef.position.y, 0.15)


# ---------------------------------------------------------------- fim e pausa

func _fim_do_dia(texto: String) -> void:
	if acabou:
		return
	acabou = true
	Estado.ultimo_atendidos = atendidos
	Estado.ultimo_ganho = ganho
	Estado.ultima_avaliacao = roundf(reputacao * 2.0) / 2.0
	Estado.dia_salvo = Estado.dia + 1
	Estado.salvar()
	Som.tocar("fim_do_dia")
	%Aviso.text = texto
	%Aviso.visible = true
	garcom.set_physics_process(false)
	for m in mesas:
		m.set_process(false)
	await get_tree().create_timer(1.5).timeout
	get_tree().change_scene_to_file("res://scenes/fim_do_dia.tscn")


func _texto_som() -> void:
	%BotaoSom.text = "SOM: LIGADO" if Estado.som_ligado else "SOM: DESLIGADO"


func _abrir_pausa() -> void:
	if acabou:
		return
	pausa.visible = true
	get_tree().paused = true


func _fechar_pausa() -> void:
	pausa.visible = false
	get_tree().paused = false


# ---------------------------------------------------------------- chão

## Desenha o chão: azulejos na cozinha e lajotas no pátio, com canteiros.
func _draw() -> void:
	# Cozinha (esquerda): azulejo xadrez
	for x in range(0, 300, 50):
		for y in range(70, 720, 50):
			var claro := (x / 50 + y / 50) % 2 == 0
			draw_rect(Rect2(x, y, 50, 50), Color(0.93, 0.94, 0.96) if claro else Color(0.82, 0.85, 0.9))
	# Fogão com 4 bocas e uma panela
	draw_rect(Rect2(20, 105, 180, 95), Color(0.35, 0.36, 0.4))
	draw_rect(Rect2(26, 111, 168, 83), Color(0.45, 0.46, 0.5))
	for boca in [Vector2(65, 135), Vector2(155, 135), Vector2(65, 172), Vector2(155, 172)]:
		draw_circle(boca, 15, Color(0.2, 0.2, 0.22))
		draw_arc(boca, 11, 0, TAU, 20, Color(1, 0.45, 0.15), 3.0)
	draw_circle(Vector2(155, 135), 22, Color(0.75, 0.2, 0.2))  # panela
	draw_circle(Vector2(155, 135), 16, Color(0.95, 0.75, 0.3))  # sopinha
	# Pátio: lajotas cor de terracota
	draw_rect(Rect2(300, 70, 980, 650), Color(0.93, 0.78, 0.6))
	for x in range(300, 1280, 70):
		for y in range(70, 720, 70):
			if (x / 70 + y / 70) % 2 == 0:
				draw_rect(Rect2(x + 2, y + 2, 66, 66), Color(0.96, 0.84, 0.68))
	# Cerca viva (grama) em cima e embaixo
	draw_rect(Rect2(300, 70, 980, 44), Color(0.45, 0.72, 0.35))
	draw_rect(Rect2(300, 700, 980, 20), Color(0.45, 0.72, 0.35))
	for x in range(310, 1280, 40):
		draw_circle(Vector2(x, 108), 22, Color(0.36, 0.62, 0.28))
