extends Control
## Cena principal: o restaurante. Toque numa comida da cozinha e depois na
## mesa do cliente que pediu aquela comida.

const COR_SELECIONADA := Color(1, 1, 0.6)

var tempo_restante := Estado.DURACAO_DIA
var reputacao := Estado.REPUTACAO_MAX
var comida_na_mao := ""
var atendidos := 0
var ganho := 0
var acabou := false
var _proximo_cliente := 0.5
var _botoes_comida := {}
var _linhas_pedido := {}
var _dinheiro_inicio := Estado.dinheiro

@onready var mesas: Array = $Mesas.get_children()
@onready var lbl_dinheiro: Label = %ValorDinheiro
@onready var lbl_tempo: Label = %ValorTempo
@onready var lbl_dia: Label = %Dia
@onready var estrelas: HBoxContainer = %Estrelas
@onready var lista_pedidos: VBoxContainer = %ListaPedidos
@onready var lbl_contador: Label = %Contador
@onready var lbl_atendidos: Label = %Atendidos
@onready var caixa_comidas: HBoxContainer = %Comidas
@onready var garcom: Control = $Garcom
@onready var bandeja: TextureRect = $Garcom/Bandeja
@onready var dica: Label = %Dica
@onready var pausa: Control = $Pausa


func _ready() -> void:
	lbl_dia.text = "DIA %d" % Estado.dia
	for i in 5:
		var e := TextureRect.new()
		e.texture = Estado.textura("estrela")
		e.custom_minimum_size = Vector2(34, 34)
		e.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		e.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		estrelas.add_child(e)
	for id in Estado.comidas_do_dia():
		var b := Button.new()
		b.custom_minimum_size = Vector2(118, 140)
		b.icon = Estado.textura(id)
		b.expand_icon = true
		b.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
		b.vertical_icon_alignment = VERTICAL_ALIGNMENT_TOP
		b.text = "$%d" % (Estado.COMIDAS[id]["preco"] + Estado.bonus_por_pedido())
		b.focus_mode = Control.FOCUS_NONE
		b.name = "Comida_" + id
		b.pressed.connect(_on_comida.bind(id))
		caixa_comidas.add_child(b)
		_botoes_comida[id] = b
	for m in mesas:
		m.tocada.connect(_on_mesa)
		m.paciencia_esgotada.connect(_on_paciencia_esgotada)
	%BotaoEngrenagem.pressed.connect(_abrir_pausa)
	%Continuar.pressed.connect(_fechar_pausa)
	%Reiniciar.pressed.connect(func():
		Estado.dinheiro = _dinheiro_inicio
		get_tree().paused = false
		get_tree().reload_current_scene())
	%Menu.pressed.connect(func():
		get_tree().paused = false
		get_tree().change_scene_to_file("res://scenes/titulo.tscn"))
	%BotaoSom.pressed.connect(func():
		Som.alternar()
		_texto_som())
	_texto_som()
	pausa.visible = false
	bandeja.visible = false
	_atualizar_hud()


func _process(delta: float) -> void:
	if acabou:
		return
	tempo_restante -= delta
	_proximo_cliente -= delta
	if _proximo_cliente <= 0.0:
		_chamar_cliente()
	_atualizar_hud()
	if tempo_restante <= 0.0:
		tempo_restante = 0.0
		_fim_do_dia("FIM DO DIA!")


func _chamar_cliente() -> void:
	_proximo_cliente = Estado.intervalo_clientes()
	var livres := mesas.filter(func(m): return m.esta_livre())
	if livres.is_empty():
		_proximo_cliente = 0.8
		return
	var mesa = livres.pick_random()
	var comida: String = Estado.comidas_do_dia().pick_random()
	mesa.chegar(Estado.ANIMAIS.pick_random(), comida, Estado.paciencia_do_dia())
	_adicionar_linha_pedido(mesa, comida)


func _on_comida(id: String) -> void:
	if acabou:
		return
	comida_na_mao = "" if comida_na_mao == id else id
	for k in _botoes_comida:
		var b: Button = _botoes_comida[k]
		b.modulate = COR_SELECIONADA if k == comida_na_mao else Color.WHITE
		b.scale = Vector2(1.08, 1.08) if k == comida_na_mao else Vector2.ONE
	bandeja.visible = comida_na_mao != ""
	if comida_na_mao != "":
		bandeja.texture = Estado.textura(comida_na_mao)
		dica.text = "Agora toque na mesa que pediu %s!" % Estado.COMIDAS[id]["nome"]
	else:
		dica.text = "Toque numa comida e depois na mesa do cliente."


func _on_mesa(mesa) -> void:
	if acabou or not mesa.esta_esperando():
		return
	if comida_na_mao == "":
		_mensagem(mesa, "Escolha a comida!", Color(0.3, 0.3, 0.3))
		return
	var fracao: float = mesa.fracao_paciencia()
	var comida := comida_na_mao
	_mover_garcom(mesa)
	if mesa.servir(comida):
		var valor: int = Estado.COMIDAS[comida]["preco"] + Estado.bonus_por_pedido() + int(round(10.0 * fracao))
		Estado.dinheiro += valor
		ganho += valor
		atendidos += 1
		if fracao > 0.6:
			reputacao = minf(Estado.REPUTACAO_MAX, reputacao + 0.25)
		_remover_linha_pedido(mesa)
		_mensagem(mesa, "+$%d" % valor, Color(0.1, 0.6, 0.1))
		Som.tocar("moeda")
	else:
		_perder_reputacao(0.5)
		_mensagem(mesa, "Pedido errado!", Color(0.85, 0.1, 0.1))
		Som.tocar("erro")
	_on_comida(comida)  # solta a comida da mão
	_atualizar_hud()


func _on_paciencia_esgotada(mesa) -> void:
	_remover_linha_pedido(mesa)
	_mensagem(mesa, "Demorou demais!", Color(0.85, 0.1, 0.1))
	Som.tocar("cliente_bravo")
	_perder_reputacao(1.0)


func _perder_reputacao(qtd: float) -> void:
	reputacao = maxf(0.0, reputacao - qtd)
	_atualizar_hud()
	if reputacao <= 0.0:
		_fim_do_dia("O restaurante fechou mais cedo...")


func _atualizar_hud() -> void:
	lbl_dinheiro.text = "$%d" % Estado.dinheiro
	var s := int(ceil(tempo_restante))
	lbl_tempo.text = "%02d:%02d" % [s / 60, s % 60]
	lbl_tempo.modulate = Color(1, 0.3, 0.3) if s <= 10 else Color.WHITE
	var estrelas_meias := roundf(reputacao * 2.0) / 2.0
	for i in estrelas.get_child_count():
		var e: TextureRect = estrelas.get_child(i)
		if estrelas_meias >= i + 1:
			e.modulate = Color.WHITE
		elif estrelas_meias >= i + 0.5:
			e.modulate = Color(1, 1, 1, 0.5)
		else:
			e.modulate = Color(0.2, 0.2, 0.2, 0.35)
	lbl_contador.text = "%d em espera" % _linhas_pedido.size()
	lbl_atendidos.text = "Atendidos: %d" % atendidos


func _adicionar_linha_pedido(mesa, comida: String) -> void:
	var linha := HBoxContainer.new()
	var icone := TextureRect.new()
	icone.texture = Estado.textura(comida)
	icone.custom_minimum_size = Vector2(40, 40)
	icone.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icone.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	var texto := Label.new()
	texto.text = "%s - Mesa %d" % [Estado.COMIDAS[comida]["nome"], mesa.numero]
	texto.add_theme_color_override("font_color", Color(0.3, 0.18, 0.08))
	texto.add_theme_font_size_override("font_size", 20)
	linha.add_child(icone)
	linha.add_child(texto)
	lista_pedidos.add_child(linha)
	_linhas_pedido[mesa] = linha


func _remover_linha_pedido(mesa) -> void:
	if _linhas_pedido.has(mesa):
		_linhas_pedido[mesa].queue_free()
		_linhas_pedido.erase(mesa)
	_atualizar_hud()


func _mover_garcom(mesa) -> void:
	var inicio := garcom.position
	var alvo: Vector2 = mesa.global_position + Vector2(mesa.size.x - 60, 220) - get_global_rect().position
	var t := create_tween()
	t.tween_property(garcom, "position", alvo, 0.25)
	t.tween_property(garcom, "position", inicio, 0.35)


func _mensagem(mesa, texto: String, cor: Color) -> void:
	var l := Label.new()
	l.text = texto
	l.add_theme_font_size_override("font_size", 30)
	l.add_theme_color_override("font_color", cor)
	l.add_theme_color_override("font_outline_color", Color.WHITE)
	l.add_theme_constant_override("outline_size", 8)
	l.size = Vector2(mesa.size.x, 40)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.position = mesa.position + $Mesas.position + Vector2(0, 150)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(l)
	var t := create_tween()
	t.tween_property(l, "position:y", l.position.y - 70, 1.0)
	t.parallel().tween_property(l, "modulate:a", 0.0, 1.0).set_delay(0.4)
	t.tween_callback(l.queue_free)


func _fim_do_dia(texto: String) -> void:
	if acabou:
		return
	acabou = true
	Estado.ultimo_atendidos = atendidos
	Estado.ultimo_ganho = ganho
	Estado.ultima_avaliacao = roundf(reputacao * 2.0) / 2.0
	Estado.dia_salvo = Estado.dia + 1
	Estado.salvar()
	Som.tocar("fim_do_dia")
	%Aviso.text = texto
	%Aviso.visible = true
	for m in mesas:
		m.set_process(false)
	await get_tree().create_timer(1.5).timeout
	get_tree().change_scene_to_file("res://scenes/fim_do_dia.tscn")


func _texto_som() -> void:
	%BotaoSom.text = "SOM: LIGADO" if Estado.som_ligado else "SOM: DESLIGADO"


func _abrir_pausa() -> void:
	if acabou:
		return
	pausa.visible = true
	get_tree().paused = true


func _fechar_pausa() -> void:
	pausa.visible = false
	get_tree().paused = false
