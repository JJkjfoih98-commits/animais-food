extends Control
## FIM DO DIA: resumo da fase, missões cumpridas, estrelas, nível e loja.

const Dados = preload("res://scripts/dados.gd")

@onready var painel_melhorias: Control = %PainelMelhorias
@onready var lista_melhorias: VBoxContainer = %ListaMelhorias


func _ready() -> void:
	%Titulo.text = "FIM DA FASE %d" % Estado.fase
	%Resumo.text = "Clientes atendidos: %d     Dinheiro ganho: $%d     Reputação: %.1f estrelas" % [
		Estado.ultimo_atendidos, Estado.ultimo_ganho, Estado.ultima_avaliacao]
	# As 3 missões: certo ou errado, com a recompensa
	for m in Estado.ultimas_missoes:
		var linha := HBoxContainer.new()
		linha.add_child(_icone("certo" if m["ok"] else "errado", 34))
		var t := Label.new()
		t.text = m["texto"] + ("   (+$%d, +%d XP)" % [m["dinheiro"], m["xp"]] if m["ok"] else "")
		t.add_theme_font_size_override("font_size", 24)
		t.add_theme_color_override("font_color", Color(0.1, 0.5, 0.1) if m["ok"] else Color(0.5, 0.3, 0.25))
		linha.add_child(t)
		%Missoes.add_child(linha)
	# Estrelas ganhas nesta fase (1 por missão cumprida)
	for i in 3:
		var e := _icone("estrela", 64)
		if i >= Estado.ultimas_estrelas:
			e.modulate = Color(0.2, 0.2, 0.2, 0.35)
		%Estrelas.add_child(e)
	%Nivel.text = "Restaurante nível %d (XP %d/%d)   ·   Dinheiro no caixa: $%d" % [
		Estado.nivel, Estado.xp, Estado.xp_para_subir(), Estado.dinheiro]
	# Botões
	var proxima := Estado.fase + 1
	%ProximaFase.visible = proxima <= Dados.FASES.size() and Estado.fase_liberada(proxima)
	%ProximaFase.pressed.connect(func():
		Estado.fase = proxima
		get_tree().change_scene_to_file("res://scenes/jogo.tscn"))
	%DeNovo.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/jogo.tscn"))
	%Mapa.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/niveis.tscn"))
	%Melhorar.pressed.connect(_abrir_melhorias)
	%FecharMelhorias.pressed.connect(func(): painel_melhorias.visible = false)
	painel_melhorias.visible = false
	if %ProximaFase.visible:
		%ProximaFase.grab_focus()


func _icone(nome: String, tamanho: int) -> TextureRect:
	var t := TextureRect.new()
	t.texture = Estado.textura(nome)
	t.custom_minimum_size = Vector2(tamanho, tamanho)
	t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	t.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	return t


func _abrir_melhorias() -> void:
	painel_melhorias.visible = true
	_montar_lista()


func _montar_lista() -> void:
	for c in lista_melhorias.get_children():
		c.queue_free()
	%Caixa.text = "Caixa: $%d" % Estado.dinheiro
	for id in Dados.MELHORIAS:
		var dados: Dictionary = Dados.MELHORIAS[id]
		var nivel: int = Estado.melhorias[id]
		var b := Button.new()
		b.name = "Melhoria_" + id
		b.custom_minimum_size = Vector2(660, 72)
		b.add_theme_font_size_override("font_size", 22)
		if nivel >= dados["max"]:
			b.text = "%s (já comprado ao máximo)\n%s" % [dados["nome"], dados["desc"]]
			b.disabled = true
		else:
			var preco := Estado.preco_melhoria(id)
			b.text = "%s  nível %d → %d  —  $%d\n%s" % [dados["nome"], nivel, nivel + 1, preco, dados["desc"]]
			b.disabled = Estado.dinheiro < preco
			b.pressed.connect(func():
				Estado.comprar_melhoria(id)
				_montar_lista()
				%Nivel.text = "Restaurante nível %d (XP %d/%d)   ·   Dinheiro no caixa: $%d" % [
					Estado.nivel, Estado.xp, Estado.xp_para_subir(), Estado.dinheiro])
		lista_melhorias.add_child(b)
