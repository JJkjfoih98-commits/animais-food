extends Control
## Resumo do dia + loja de melhorias + botão para o próximo dia.

@onready var painel_melhorias: Control = %PainelMelhorias
@onready var lista_melhorias: VBoxContainer = %ListaMelhorias


func _ready() -> void:
	%Titulo.text = "FIM DO DIA %d" % Estado.dia
	%Atendidos.text = "CLIENTES ATENDIDOS: %d" % Estado.ultimo_atendidos
	%Ganho.text = "DINHEIRO GANHO: $%d" % Estado.ultimo_ganho
	%Total.text = "Dinheiro no caixa: $%d" % Estado.dinheiro
	for i in 5:
		var e := TextureRect.new()
		e.texture = Estado.textura("estrela")
		e.custom_minimum_size = Vector2(56, 56)
		e.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		e.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		var a := Estado.ultima_avaliacao
		e.modulate = Color.WHITE if a >= i + 1 else (Color(1, 1, 1, 0.5) if a >= i + 0.5 else Color(0.2, 0.2, 0.2, 0.35))
		%Estrelas.add_child(e)
	%Melhorar.pressed.connect(_abrir_melhorias)
	%ProximoDia.pressed.connect(_proximo_dia)
	%FecharMelhorias.pressed.connect(func(): painel_melhorias.visible = false)
	painel_melhorias.visible = false
	%ProximoDia.grab_focus()


func _proximo_dia() -> void:
	Estado.dia += 1
	Estado.dia_salvo = Estado.dia
	Estado.salvar()
	get_tree().change_scene_to_file("res://scenes/jogo.tscn")


func _abrir_melhorias() -> void:
	painel_melhorias.visible = true
	_montar_lista()


func _montar_lista() -> void:
	for c in lista_melhorias.get_children():
		c.queue_free()
	%Caixa.text = "Caixa: $%d" % Estado.dinheiro
	for id in Estado.MELHORIAS:
		var dados: Dictionary = Estado.MELHORIAS[id]
		var nivel: int = Estado.melhorias[id]
		var b := Button.new()
		b.name = "Melhoria_" + id
		b.custom_minimum_size = Vector2(620, 80)
		b.add_theme_font_size_override("font_size", 24)
		if nivel >= Estado.NIVEL_MAX_MELHORIA:
			b.text = "%s (nível máximo)\n%s" % [dados["nome"], dados["desc"]]
			b.disabled = true
		else:
			var preco := Estado.preco_melhoria(id)
			b.text = "%s  nível %d → %d  —  $%d\n%s" % [dados["nome"], nivel, nivel + 1, preco, dados["desc"]]
			b.disabled = Estado.dinheiro < preco
			b.pressed.connect(func():
				Estado.comprar_melhoria(id)
				_montar_lista()
				%Total.text = "Dinheiro no caixa: $%d" % Estado.dinheiro)
		lista_melhorias.add_child(b)
