extends Control
## Tela de título do Animais Food.

@onready var botao_jogar: Button = $Centro/Caixa/BotaoJogar
@onready var botao_novo: Button = $Centro/Caixa/BotaoNovo


func _ready() -> void:
	botao_jogar.pressed.connect(_on_jogar)
	$Centro/Caixa/BotaoInstrucoes.pressed.connect(_on_instrucoes)
	botao_novo.pressed.connect(_on_novo_jogo)
	# Com progresso salvo, JOGAR continua de onde parou.
	if Estado.tem_progresso():
		botao_jogar.text = "CONTINUAR (DIA %d)" % Estado.dia_salvo
		botao_jogar.add_theme_font_size_override("font_size", 32)
		botao_novo.visible = true
	botao_jogar.grab_focus()


func _on_jogar() -> void:
	Estado.carregar()
	get_tree().change_scene_to_file("res://scenes/jogo.tscn")


func _on_novo_jogo() -> void:
	Estado.novo_jogo()
	get_tree().change_scene_to_file("res://scenes/jogo.tscn")


func _on_instrucoes() -> void:
	get_tree().change_scene_to_file("res://scenes/instrucoes.tscn")
