extends Control
## TELA DE TÍTULO: JOGAR abre o mapa das fases; NOVO JOGO apaga o progresso.
## Enfeite: o Totó passeia embaixo e os clientes pulam em cima.

const Dados = preload("res://scripts/dados.gd")

@onready var botao_jogar: Button = $Centro/Caixa/BotaoJogar
@onready var botao_novo: Button = $Centro/Caixa/BotaoNovo
var _toto: CharacterBody2D
var _bichos: Array = []
var _tempo := 0.0

func _ready() -> void:
	botao_jogar.pressed.connect(_on_jogar)
	$Centro/Caixa/BotaoInstrucoes.pressed.connect(_on_instrucoes)
	botao_novo.pressed.connect(_on_novo_jogo)
	# Com progresso salvo, mostra o nível e o botão de começar do zero.
	if Estado.tem_progresso():
		botao_jogar.text = "JOGAR (NÍVEL %d)" % Estado.nivel
		botao_jogar.add_theme_font_size_override("font_size", 34)
		botao_novo.visible = true
	botao_jogar.grab_focus()
	_enfeitar()


func _on_jogar() -> void:
	get_tree().change_scene_to_file("res://scenes/niveis.tscn")


func _on_novo_jogo() -> void:
	Estado.novo_jogo()
	get_tree().change_scene_to_file("res://scenes/niveis.tscn")


func _on_instrucoes() -> void:
	get_tree().change_scene_to_file("res://scenes/instrucoes.tscn")


## Coloca o Totó andando e os animais pulando.
func _enfeitar() -> void:
	_toto = load("res://scenes/garcom.tscn").instantiate()
	_toto.position = Vector2(120, 708)
	_toto.set_physics_process(false)  # aqui quem mexe nele é este script
	add_child(_toto)
	for i in Dados.ANIMAIS.size():
		var s := Sprite2D.new()
		s.texture = Estado.textura(Dados.ANIMAIS[i])
		s.scale = Vector2(0.24, 0.24)
		s.position = Vector2(60 + i * 72, 64)
		add_child(s)
		_bichos.append(s)


func _process(delta: float) -> void:
	_tempo += delta
	# Os animais pulam um depois do outro (uma "ola").
	for i in _bichos.size():
		_bichos[i].position.y = 64 - absf(sin(_tempo * 3.0 - i * 0.45)) * 18.0
	# O Totó anda de um lado para o outro e vira nas pontas.
	if _toto.position.x > 1160:
		_toto.olhando_direita = false
	elif _toto.position.x < 120:
		_toto.olhando_direita = true
	_toto.velocity = Vector2(160 if _toto.olhando_direita else -160, 0)
	_toto.move_and_slide()
	_toto.animar_patas(delta)