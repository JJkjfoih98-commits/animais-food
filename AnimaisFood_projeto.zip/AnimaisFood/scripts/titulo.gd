extends Control
## TELA DE TÍTULO: JOGAR abre o mapa das fases; NOVO JOGO apaga o progresso.

@onready var botao_jogar: Button = $Centro/Caixa/BotaoJogar
@onready var botao_novo: Button = $Centro/Caixa/BotaoNovo


func _ready() -> void:
	botao_jogar.pressed.connect(_on_jogar)
	$Centro/Caixa/BotaoInstrucoes.pressed.connect(_on_instrucoes)
	botao_novo.pressed.connect(_on_novo_jogo)
	# Com progresso salvo, mostra o nível e o botão de começar do zero.
	if Estado.tem_progresso():
		botao_jogar.text = "JOGAR (NÍVEL %d)" % Estado.nivel
		botao_jogar.add_theme_font_size_override("font_size", 34)
		botao_novo.visible = true
	botao_jogar.grab_focus()


func _on_jogar() -> void:
	get_tree().change_scene_to_file("res://scenes/niveis.tscn")


func _on_novo_jogo() -> void:
	Estado.novo_jogo()
	get_tree().change_scene_to_file("res://scenes/niveis.tscn")


func _on_instrucoes() -> void:
	get_tree().change_scene_to_file("res://scenes/instrucoes.tscn")
