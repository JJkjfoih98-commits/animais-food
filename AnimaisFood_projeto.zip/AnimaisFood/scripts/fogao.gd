extends Node2D
## O FOGÃO COM FORNO: em cima tem a panela, embaixo tem o forno com porta.
## Mostra a comida de VERDADE que está sendo feita, crescendo com o progresso.

const TAMANHO := Vector2(74, 100)
const PONTO := Vector2(108, 104)       # onde o cozinheiro fica de pé
const PANELA := Vector2(34, 10)        # centro da panela (relativo)

var comida_panela := ""   # comida cozinhando na panela ("" = vazia)
var comida_forno := ""    # comida assando no forno
var progresso := 0.0      # 0 a 1 (quanto já cozinhou)
var porta_forno := 0.0    # 0 = fechada, 1 = aberta
var _tempo := 0.0

@onready var vapor: CPUParticles2D = $Vapor


func ponto() -> Vector2:
	return global_position + PONTO


func abrir_forno() -> void:
	var t := create_tween()
	t.tween_property(self, "porta_forno", 1.0, 0.3)
	await t.finished


func fechar_forno() -> void:
	var t := create_tween()
	t.tween_property(self, "porta_forno", 0.0, 0.3)
	await t.finished


func _process(delta: float) -> void:
	_tempo += delta
	vapor.emitting = comida_panela != ""
	queue_redraw()


func _draw() -> void:
	draw_rect(Rect2(Vector2(4, 6), TAMANHO), Color(0, 0, 0, 0.15))
	# Corpo do fogão
	draw_rect(Rect2(Vector2.ZERO, TAMANHO), Color(0.42, 0.43, 0.48))
	draw_rect(Rect2(Vector2(0, 0), Vector2(TAMANHO.x, 26)), Color(0.3, 0.31, 0.35))
	# Boca acesa embaixo da panela
	var fogo := 0.6 + 0.4 * absf(sin(_tempo * 9.0)) if comida_panela != "" else 0.0
	draw_arc(PANELA + Vector2(0, 6), 14, 0, TAU, 20, Color(1, 0.45, 0.1, 0.3 + fogo * 0.7), 3.0)
	# Panela (com cabo para a direita)
	draw_line(PANELA + Vector2(16, 0), PANELA + Vector2(34, -2), Color(0.2, 0.2, 0.22), 5.0)
	draw_circle(PANELA, 17, Color(0.25, 0.25, 0.28))
	draw_circle(PANELA, 14, Color(0.5, 0.5, 0.55))
	if comida_panela != "":
		# A comida cresce e "borbulha" enquanto cozinha
		var tam := 16.0 + 18.0 * progresso + sin(_tempo * 10.0) * 1.5
		draw_texture_rect(Estado.textura(comida_panela), Rect2(PANELA - Vector2(tam, tam + 4) / 2.0, Vector2(tam, tam)), false)
		for i in 3:
			var b := fmod(_tempo * 1.5 + i * 0.33, 1.0)
			draw_circle(PANELA + Vector2(-8 + i * 8, 4 - b * 16), 2.5 * (1.0 - b), Color(1, 1, 1, 0.8 - b * 0.8))
	# Forno: janela de vidro e porta que abre para baixo
	var area := Rect2(Vector2(6, 34), Vector2(TAMANHO.x - 12, 58))
	var brilho := 0.5 + 0.5 * sin(_tempo * 4.0) if comida_forno != "" else 0.0
	draw_rect(area, Color(0.15, 0.12, 0.1).lerp(Color(0.9, 0.45, 0.1), 0.35 + brilho * 0.35) if comida_forno != "" else Color(0.15, 0.13, 0.12))
	if comida_forno != "":
		var tam := 20.0 + 16.0 * progresso
		draw_texture_rect(Estado.textura(comida_forno), Rect2(area.get_center() - Vector2(tam, tam) / 2.0 + Vector2(0, 6), Vector2(tam, tam)), false)
	# A porta: quando abre, ela "desce" e fica baixinha
	var altura := area.size.y * (1.0 - porta_forno * 0.85)
	var porta := Rect2(Vector2(area.position.x, area.end.y - altura), Vector2(area.size.x, altura))
	draw_rect(porta, Color(0.55, 0.56, 0.6))
	if porta_forno < 0.5:
		draw_rect(porta.grow(-8), Color(0.2, 0.15, 0.12, 0.6) if comida_forno == "" else Color(1, 0.6, 0.2, 0.35))
	draw_line(Vector2(porta.position.x + 8, porta.position.y + 4), Vector2(porta.end.x - 8, porta.position.y + 4), Color(0.85, 0.85, 0.9), 3.0)
	draw_rect(Rect2(Vector2.ZERO, TAMANHO), Color(0.2, 0.2, 0.22), false, 2.0)
