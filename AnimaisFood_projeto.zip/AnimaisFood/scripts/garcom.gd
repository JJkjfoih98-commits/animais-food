extends CharacterBody2D
## O GARÇOM TOTÓ (o personagem que o jogador controla)
## - Anda com as setas, com W A S D ou com o joystick da tela.
## - Carrega um prato por vez (o prato fica equilibrado em cima da cabeça).
## - O desenho do Totó é feito por código, em partes: corpo, cabeça, orelhas,
##   rabo e 4 patinhas. Assim dá para mexer cada parte separada!
## CharacterBody2D é o tipo de nó do Godot para personagens: o comando
## move_and_slide() faz ele andar e parar quando bate em mesas e paredes.

const VELOCIDADE := 340.0      # pixels por segundo
const PASSOS_POR_SEGUNDO := 2.6 # quantos passos ele dá andando na velocidade máxima

# Cores do Totó (parecidas com o emoji de cachorro do jogo)
const COR_PELO := Color(0.96, 0.70, 0.38)
const COR_PELO_ESCURO := Color(0.80, 0.52, 0.26)
const COR_ORELHA := Color(0.62, 0.38, 0.18)
const COR_BARRIGA := Color(1.0, 0.90, 0.72)
const COR_GRAVATA := Color(0.85, 0.15, 0.2)

## O joystick da tela (o script do jogo liga ele aqui).
var joystick: Control
## A comida que o Totó está carregando. "" quer dizer mãos vazias.
var prato := ""

# --- Estado da animação ---
## Fase do passo: um número que vai crescendo enquanto ele anda.
## sin(fase_passo) vai de -1 a 1 e faz as patinhas irem para frente e para trás.
var fase_passo := 0.0
## Ângulo de cada patinha (em radianos), usado no desenho.
var angulo_patas := [0.0, 0.0, 0.0, 0.0]  # [frente perto, frente longe, trás perto, trás longe]
var andando := false
var olhando_direita := true
var _tempo := 0.0              # relógio para respirar e abanar o rabo
var _pulinho := 0.0            # quanto o corpo sobe a cada passo
var _rabo := 0.0               # ângulo do rabo
var _orelha := 0.0             # ângulo das orelhas
var _respira := 0.0            # corpo "enche" um pouquinho quando parado
var _tempo_proximo_passo := 0.0

@onready var icone_prato: Sprite2D = $Prato
@onready var dica: Label = $Dica


func _ready() -> void:
	criar_teclas()
	icone_prato.visible = false
	dica.visible = false


## Cria as teclas do jogo: setas + WASD para andar, Espaço/E/Enter para a ação.
## (Fazer por código é mais fácil de entender do que pelo menu do Godot.)
static func criar_teclas() -> void:
	var teclas := {
		"andar_esquerda": [KEY_LEFT, KEY_A],
		"andar_direita": [KEY_RIGHT, KEY_D],
		"andar_cima": [KEY_UP, KEY_W],
		"andar_baixo": [KEY_DOWN, KEY_S],
		"acao": [KEY_SPACE, KEY_E, KEY_ENTER],
	}
	for nome in teclas:
		if InputMap.has_action(nome):
			continue
		InputMap.add_action(nome)
		for tecla in teclas[nome]:
			var evento := InputEventKey.new()
			evento.physical_keycode = tecla
			InputMap.action_add_event(nome, evento)


func _physics_process(delta: float) -> void:
	# 1) Para onde o jogador quer ir? Teclado ou joystick.
	var direcao := Input.get_vector("andar_esquerda", "andar_direita", "andar_cima", "andar_baixo")
	if joystick and joystick.direcao != Vector2.ZERO:
		direcao = joystick.direcao

	# 2) Anda (e para nas mesas/paredes sozinho).
	velocity = direcao * VELOCIDADE
	move_and_slide()

	# 3) Vira para o lado que está andando.
	if absf(velocity.x) > 5.0:
		olhando_direita = velocity.x > 0.0

	# 4) Mexe as patinhas, o rabo e as orelhas.
	animar_patas(delta)


## ANIMAÇÃO DAS PATINHAS (ciclo de caminhada)
## Cachorros andam mexendo as patas em "X": a pata da frente de um lado anda
## junto com a pata de trás do outro lado. Por isso usamos +sin e -sin.
func animar_patas(delta: float) -> void:
	_tempo += delta
	# A velocidade da animação depende da velocidade real (0 = parado, 1 = correndo).
	var rapidez := clampf(get_real_velocity().length() / VELOCIDADE, 0.0, 1.0)
	andando = rapidez > 0.05

	if andando:
		# Avança o passo: mais rápido quando ele anda mais rápido.
		fase_passo += delta * TAU * PASSOS_POR_SEGUNDO * rapidez
		var balanco := sin(fase_passo) * 0.55 * rapidez  # até ~30 graus
		angulo_patas[0] = balanco    # frente (perto)
		angulo_patas[3] = balanco    # trás (longe)   -> par diagonal 1
		angulo_patas[1] = -balanco   # frente (longe)
		angulo_patas[2] = -balanco   # trás (perto)   -> par diagonal 2
		_pulinho = absf(cos(fase_passo)) * 5.0 * rapidez   # sobe um pouquinho a cada passo
		_rabo = sin(_tempo * 14.0) * 0.5                    # rabo abanando rápido
		_orelha = sin(fase_passo * 2.0) * 0.25              # orelhas balançando
		_respira = 0.0
		# Barulhinho de passo
		_tempo_proximo_passo -= delta
		if _tempo_proximo_passo <= 0.0:
			_tempo_proximo_passo = 0.5 / PASSOS_POR_SEGUNDO
			Som.tocar("passo")
	else:
		# Parado: as patas voltam devagar para o lugar, ele respira e abana o rabo.
		for i in 4:
			angulo_patas[i] = lerpf(angulo_patas[i], 0.0, 0.25)
		_pulinho = lerpf(_pulinho, 0.0, 0.25)
		_rabo = sin(_tempo * 6.0) * 0.35
		_orelha = lerpf(_orelha, sin(_tempo * 2.0) * 0.06, 0.2)
		_respira = sin(_tempo * 3.0) * 0.03

	# O prato na cabeça balança junto com o corpo.
	var x_cabeca := 30.0 if olhando_direita else -30.0
	icone_prato.position = Vector2(x_cabeca, -124.0 - _pulinho + sin(_tempo * 7.0) * 2.0)
	queue_redraw()  # pede para o Godot chamar _draw() de novo


## Pega uma comida do balcão.
func pegar(comida: String) -> void:
	prato = comida
	icone_prato.texture = Estado.textura(comida)
	icone_prato.visible = true
	icone_prato.scale = Vector2(0.05, 0.05)
	create_tween().tween_property(icone_prato, "scale", Vector2(0.26, 0.26), 0.2).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


## Larga o prato (depois de entregar).
func soltar() -> void:
	prato = ""
	icone_prato.visible = false


## Mostra (ou esconde, se texto for "") a dica em cima do Totó.
func mostrar_dica(texto: String) -> void:
	dica.text = texto
	dica.visible = texto != ""


# ---------------------------------------------------------------- DESENHO

## Desenha o Totó inteiro. As coordenadas são para ele olhando para a DIREITA;
## quando olha para a esquerda, espelhamos tudo com escala X = -1.
## O ponto (0, 0) é o chão, entre as patinhas.
func _draw() -> void:
	# Sombra (não espelha)
	draw_set_transform(Vector2(0, 2), 0.0, Vector2(1.0, 0.35))
	draw_circle(Vector2.ZERO, 44.0, Color(0, 0, 0, 0.22))

	var lado := 1.0 if olhando_direita else -1.0
	draw_set_transform(Vector2(0, -_pulinho), 0.0, Vector2(lado, 1.0))

	# Patas do lado de LÁ (mais escuras, desenhadas antes, ficam atrás do corpo)
	_pata(Vector2(24, -30), angulo_patas[1], COR_PELO_ESCURO)
	_pata(Vector2(-20, -30), angulo_patas[3], COR_PELO_ESCURO)
	# Rabo (sai de trás do corpo e abana)
	var base_rabo := Vector2(-34, -44)
	var meio := base_rabo + Vector2(-12, -12).rotated(_rabo)
	var ponta := meio + Vector2(-4, -16).rotated(_rabo * 1.5)
	draw_polyline(PackedVector2Array([base_rabo, meio, ponta]), COR_PELO_ESCURO, 9.0, true)
	draw_circle(ponta, 4.5, COR_PELO_ESCURO)
	# Corpo (respira quando parado)
	_elipse(Vector2(0, -44), Vector2(36, 20) * (1.0 + _respira), COR_PELO)
	_elipse(Vector2(4, -36), Vector2(24, 9), COR_BARRIGA)
	# Patas do lado de CÁ (na frente do corpo)
	_pata(Vector2(18, -30), angulo_patas[0], COR_PELO)
	_pata(Vector2(-26, -30), angulo_patas[2], COR_PELO)
	# Gravatinha de garçom
	var g := Vector2(26, -56)
	draw_colored_polygon(PackedVector2Array([g, g + Vector2(-8, -6), g + Vector2(-8, 6)]), COR_GRAVATA)
	draw_colored_polygon(PackedVector2Array([g, g + Vector2(8, -6), g + Vector2(8, 6)]), COR_GRAVATA)
	draw_circle(g, 3.0, COR_GRAVATA.darkened(0.3))
	# Cabeça
	var c := Vector2(34, -72)
	draw_circle(c, 19.0, COR_PELO)
	_elipse(c + Vector2(14, 6), Vector2(12, 9), COR_BARRIGA)         # focinho
	draw_circle(c + Vector2(24, 2), 4.0, Color(0.1, 0.08, 0.08))      # nariz
	draw_circle(c + Vector2(4, -5), 3.4, Color(0.1, 0.08, 0.08))      # olho
	draw_circle(c + Vector2(5, -6), 1.2, Color.WHITE)                 # brilho do olho
	draw_arc(c + Vector2(17, 10), 5.0, 0.2, 1.6, 8, Color(0.3, 0.15, 0.1), 2.0)  # sorriso
	# Orelha caída (balança)
	var o := c + Vector2(-8, -12)
	var orelha := PackedVector2Array([o, o + Vector2(-12, 6).rotated(_orelha), o + Vector2(-8, 26).rotated(_orelha), o + Vector2(2, 20).rotated(_orelha)])
	draw_colored_polygon(orelha, COR_ORELHA)


## Uma patinha: começa no ombro/quadril e gira pelo ângulo (como um pêndulo).
func _pata(topo: Vector2, angulo: float, cor: Color) -> void:
	var comprimento := 30.0
	var pe := topo + Vector2(sin(angulo), cos(angulo)) * comprimento
	draw_line(topo, pe, cor, 10.0, true)
	_elipse(pe + Vector2(3, -1), Vector2(7, 4.5), cor.darkened(0.1))   # o pezinho


## Desenha uma elipse (círculo achatado) preenchida.
func _elipse(centro: Vector2, raio: Vector2, cor: Color) -> void:
	var pontos := PackedVector2Array()
	for i in 24:
		var a := TAU * i / 24.0
		pontos.append(centro + Vector2(cos(a) * raio.x, sin(a) * raio.y))
	draw_colored_polygon(pontos, cor)
