extends CharacterBody2D
## O GARÇOM TOTÓ (o personagem que o jogador controla)
## - Anda com as setas, com W A S D ou com o joystick da tela.
## - Carrega um prato por vez (a comida aparece em cima da cabeça dele).
## CharacterBody2D é o tipo de nó do Godot para personagens: o comando
## move_and_slide() faz ele andar e parar quando bate em mesas e paredes.

const VELOCIDADE := 340.0  # pixels por segundo

## O joystick da tela (o script do jogo liga ele aqui).
var joystick: Control
## A comida que o Totó está carregando. "" quer dizer mãos vazias.
var prato := ""

var _tempo_andando := 0.0
var _tempo_proximo_passo := 0.0

@onready var corpo: Sprite2D = $Corpo
@onready var icone_prato: Sprite2D = $Prato
@onready var dica: Label = $Dica


func _ready() -> void:
	criar_teclas()
	icone_prato.visible = false
	dica.visible = false


## Cria as teclas do jogo: setas + WASD para andar, Espaço/E/Enter para a ação.
## (Fazer por código é mais fácil de entender do que pelo menu do Godot.)
static func criar_teclas() -> void:
	var teclas := {
		"andar_esquerda": [KEY_LEFT, KEY_A],
		"andar_direita": [KEY_RIGHT, KEY_D],
		"andar_cima": [KEY_UP, KEY_W],
		"andar_baixo": [KEY_DOWN, KEY_S],
		"acao": [KEY_SPACE, KEY_E, KEY_ENTER],
	}
	for nome in teclas:
		if InputMap.has_action(nome):
			continue
		InputMap.add_action(nome)
		for tecla in teclas[nome]:
			var evento := InputEventKey.new()
			evento.physical_keycode = tecla
			InputMap.action_add_event(nome, evento)


func _physics_process(delta: float) -> void:
	# 1) Para onde o jogador quer ir? Teclado ou joystick.
	var direcao := Input.get_vector("andar_esquerda", "andar_direita", "andar_cima", "andar_baixo")
	if joystick and joystick.direcao != Vector2.ZERO:
		direcao = joystick.direcao

	# 2) Anda (e para nas mesas/paredes sozinho).
	velocity = direcao * VELOCIDADE
	move_and_slide()

	# 3) Animação simples: balança e dá pulinhos enquanto anda.
	if velocity.length() > 20.0:
		_tempo_andando += delta
		corpo.rotation = sin(_tempo_andando * 14.0) * 0.08
		corpo.position.y = -62.0 - absf(sin(_tempo_andando * 14.0)) * 8.0
		if absf(velocity.x) > 5.0:
			corpo.flip_h = velocity.x > 0.0  # o desenho olha para a esquerda
		_tempo_proximo_passo -= delta
		if _tempo_proximo_passo <= 0.0:
			_tempo_proximo_passo = 0.26
			Som.tocar("passo")
	else:
		_tempo_andando = 0.0
		corpo.rotation = lerpf(corpo.rotation, 0.0, 0.3)
		corpo.position.y = lerpf(corpo.position.y, -62.0, 0.3)

	# O prato na cabeça balança um pouquinho.
	icone_prato.position.y = corpo.position.y - 70.0 + sin(Time.get_ticks_msec() / 150.0) * 3.0


## Pega uma comida do balcão.
func pegar(comida: String) -> void:
	prato = comida
	icone_prato.texture = Estado.textura(comida)
	icone_prato.visible = true
	icone_prato.scale = Vector2(0.05, 0.05)
	create_tween().tween_property(icone_prato, "scale", Vector2(0.3, 0.3), 0.2).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


## Larga o prato (depois de entregar).
func soltar() -> void:
	prato = ""
	icone_prato.visible = false


## Mostra (ou esconde, se texto for "") a dica em cima do Totó.
func mostrar_dica(texto: String) -> void:
	dica.text = texto
	dica.visible = texto != ""


## Sombra redonda no chão, embaixo do Totó.
func _draw() -> void:
	draw_set_transform(Vector2(0, 4), 0.0, Vector2(1.0, 0.4))
	draw_circle(Vector2.ZERO, 42.0, Color(0, 0, 0, 0.22))
