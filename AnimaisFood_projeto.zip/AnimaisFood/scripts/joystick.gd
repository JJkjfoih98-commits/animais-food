extends Control
## JOYSTICK VIRTUAL (estilo jogos de celular)
## Coloque o dedo na roda e arraste a bolinha: o garçom anda nessa direção.
## Também funciona com o mouse, porque nas configurações do projeto o mouse
## "vira toque" (input_devices/pointing/emulate_touch_from_mouse = true).

const RAIO_BASE := 90.0     # tamanho da roda de fundo
const RAIO_BOLINHA := 42.0  # tamanho da bolinha que o dedo arrasta

## Direção para onde o jogador está empurrando (de -1 a 1 em X e Y).
## O garçom lê esta variável todo quadro.
var direcao := Vector2.ZERO

var _dedo := -1               # qual dedo está segurando o joystick (-1 = nenhum)
var _bolinha := Vector2.ZERO  # onde a bolinha está, em relação ao centro


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func _centro() -> Vector2:
	return size / 2.0


## Converte a posição do toque (na tela) para a posição dentro do joystick.
func _para_local(pos_tela: Vector2) -> Vector2:
	return get_global_transform_with_canvas().affine_inverse() * pos_tela


func _input(event: InputEvent) -> void:
	# Dedo encostou ou saiu da tela
	if event is InputEventScreenTouch:
		var local := _para_local(event.position)
		var dentro := local.distance_to(_centro()) <= RAIO_BASE * 1.3
		if event.pressed and _dedo == -1 and dentro:
			_dedo = event.index
			_mover_bolinha(local)
			get_viewport().set_input_as_handled()
		elif not event.pressed and event.index == _dedo:
			_soltar()
	# Dedo arrastando pela tela
	elif event is InputEventScreenDrag and event.index == _dedo:
		_mover_bolinha(_para_local(event.position))
		get_viewport().set_input_as_handled()


func _mover_bolinha(local: Vector2) -> void:
	# A bolinha segue o dedo, mas não sai de dentro da roda.
	_bolinha = (local - _centro()).limit_length(RAIO_BASE)
	direcao = _bolinha / RAIO_BASE
	if direcao.length() < 0.15:  # zona morta: encostar no meio não anda
		direcao = Vector2.ZERO
	queue_redraw()


func _soltar() -> void:
	_dedo = -1
	_bolinha = Vector2.ZERO
	direcao = Vector2.ZERO
	queue_redraw()


## Desenha a roda e a bolinha (sem precisar de imagem).
func _draw() -> void:
	var c := _centro()
	draw_circle(c, RAIO_BASE, Color(1, 1, 1, 0.25))
	draw_arc(c, RAIO_BASE, 0, TAU, 48, Color(1, 1, 1, 0.7), 4.0, true)
	draw_circle(c + _bolinha, RAIO_BOLINHA, Color(1, 0.6, 0.25, 0.9) if _dedo != -1 else Color(1, 1, 1, 0.75))
	draw_arc(c + _bolinha, RAIO_BOLINHA, 0, TAU, 32, Color(0.55, 0.25, 0.12, 0.8), 3.0, true)
