extends Node2D
## UM COZINHEIRO DESENHADO POR CÓDIGO (o Chef Elefante ou a Ajudante Coelha)
## Ele fica de pé, de lado, e tem: pernas, corpo de avental, cabeça, braços
## com cotovelo e mão, e o que estiver segurando (ingredientes ou o prato).
## Ações que ele sabe fazer (variável "acao"):
##   "parado", "mexendo" (colher na panela), "picando" (faca na tábua),
##   "alavanca" (máquina de sorvete) e "forno" (empurrar a assadeira).
## Andar é automático: quando a posição muda, as pernas e os braços balançam.

## "elefante" (o chef) ou "coelha" (a ajudante). Muda só a cabeça e as cores.
@export var especie := "elefante"

var acao := "parado"
var olhando_direita := false
## O que está nas mãos: nomes de imagens (ex.: "ing_ovo" ou "pizza").
var itens: Array = []
var andando := false

# Ângulos atuais dos braços e pernas (em radianos). 0 = apontando para baixo,
# positivo = para a frente. Cada braço tem 2 partes: ombro->cotovelo e cotovelo->mão.
var braco_perto := Vector2(0.15, 0.25)   # (ombro, cotovelo)
var braco_longe := Vector2(-0.1, 0.25)
var perna_perto := 0.0
var perna_longe := 0.0
var _fase_passo := 0.0
var _tempo := 0.0
var _balanco := 0.0      # o corpo balança de um lado pro outro trabalhando
var _pos_antes := Vector2.ZERO

const COMP_BRACO := 16.0   # tamanho de cada parte do braço
const COMP_PERNA := 22.0


func _ready() -> void:
	_pos_antes = position


# ---------------------------------------------------------------- comandos

## Anda até um ponto em "segundos" (use com await: await chef.andar_ate(...)).
func andar_ate(destino: Vector2, segundos: float) -> void:
	if destino.distance_to(position) < 2.0:
		return
	olhando_direita = destino.x > position.x
	var t := create_tween()
	t.tween_property(self, "position", destino, maxf(segundos, 0.05))
	await t.finished


## Faz uma ação (mexer, picar...) durante alguns segundos.
func trabalhar(nova_acao: String, segundos: float) -> void:
	acao = nova_acao
	var t := create_tween()
	t.tween_interval(maxf(segundos, 0.05))
	await t.finished
	acao = "parado"


func olhar_para(x: float) -> void:
	olhando_direita = x > global_position.x


# ---------------------------------------------------------------- animação

func _process(delta: float) -> void:
	_tempo += delta
	# Está andando? (a posição mudou desde o quadro anterior)
	var movimento := position.distance_to(_pos_antes)
	_pos_antes = position
	andando = movimento > 0.5
	if andando:
		_fase_passo += movimento * 0.12

	# 1) Para onde os braços e pernas QUEREM ir (o "alvo" de cada ação)
	var alvo_perto := Vector2(0.15 + sin(_tempo * 2.0) * 0.05, 0.25)
	var alvo_longe := Vector2(-0.1 - sin(_tempo * 2.0) * 0.05, 0.25)
	var alvo_balanco := 0.0
	var alvo_perna := 0.0
	if andando:
		alvo_perto = Vector2(sin(_fase_passo) * 0.6, 0.35)
		alvo_longe = Vector2(-sin(_fase_passo) * 0.6, 0.35)
		alvo_perna = sin(_fase_passo) * 0.5
	if not itens.is_empty():
		# segurando alguma coisa: os dois braços para a frente
		alvo_perto = Vector2(1.3, 0.2)
		alvo_longe = Vector2(1.15, 0.25)
	match acao:
		"mexendo":   # a mão gira a colher em círculo dentro da panela
			alvo_perto = Vector2(1.45 + sin(_tempo * 7.0) * 0.22, 0.5 + cos(_tempo * 7.0) * 0.35)
			alvo_longe = Vector2(0.95, 0.3)
			alvo_balanco = sin(_tempo * 3.5) * 0.06
		"picando":   # a faca sobe e desce
			alvo_perto = Vector2(1.2, 0.2 + absf(sin(_tempo * 9.0)) * 1.0)
			alvo_longe = Vector2(1.1, 0.3)
			alvo_balanco = sin(_tempo * 4.5) * 0.04
		"alavanca":  # puxa a alavanca da máquina para cima e para baixo
			alvo_perto = Vector2(1.9 + sin(_tempo * 4.0) * 0.5, 0.2)
			alvo_longe = Vector2(0.2, 0.3)
			alvo_balanco = sin(_tempo * 4.0) * 0.05
		"forno":     # empurra/puxa a assadeira
			alvo_perto = Vector2(1.55 + sin(_tempo * 2.5) * 0.1, 0.1)
			alvo_longe = Vector2(1.45 + sin(_tempo * 2.5) * 0.1, 0.1)
			alvo_balanco = 0.08

	# 2) Amortecimento: chega no alvo aos poucos (fica suave, sem "pulos")
	var suave := 1.0 - exp(-12.0 * delta)
	braco_perto = braco_perto.lerp(alvo_perto, suave)
	braco_longe = braco_longe.lerp(alvo_longe, suave)
	perna_perto = lerpf(perna_perto, alvo_perna, suave)
	perna_longe = lerpf(perna_longe, -alvo_perna, suave)
	_balanco = lerpf(_balanco, alvo_balanco, suave)
	queue_redraw()


# ---------------------------------------------------------------- desenho

func _draw() -> void:
	var coelha := especie == "coelha"
	var cor_pele := Color(0.95, 0.95, 0.97) if coelha else Color(0.66, 0.68, 0.74)
	var cor_pele_escura := cor_pele.darkened(0.18)
	var cor_roupa := Color(1, 1, 1)
	var cor_avental := Color(1.0, 0.62, 0.72) if coelha else Color(0.95, 0.95, 0.9)
	var cor_calca := Color(0.3, 0.3, 0.38)

	# Sombra
	draw_set_transform(Vector2(0, 2), 0.0, Vector2(1.0, 0.35))
	draw_circle(Vector2.ZERO, 26.0, Color(0, 0, 0, 0.2))
	# Daqui em diante desenhamos olhando para a DIREITA e espelhamos se precisar.
	var lado := 1.0 if olhando_direita else -1.0
	var pulinho := absf(sin(_fase_passo)) * 3.0 if andando else 0.0
	draw_set_transform(Vector2(0, -pulinho), _balanco * lado, Vector2(lado, 1.0))

	# Perna e braço do lado de LÁ (mais escuros, atrás do corpo)
	_perna(Vector2(-3, -22), perna_longe, cor_calca.darkened(0.25))
	_braco(Vector2(0, -64), braco_longe, cor_roupa.darkened(0.15), cor_pele_escura)
	# Corpo com avental
	_elipse(Vector2(0, -44), Vector2(19, 26), cor_roupa)
	_elipse(Vector2(7, -38), Vector2(13, 18), cor_avental)
	# Perna do lado de CÁ
	_perna(Vector2(3, -22), perna_perto, cor_calca)
	# Cabeça
	var c := Vector2(3, -82)
	if coelha:
		_cabeca_coelha(c, cor_pele)
	else:
		_cabeca_elefante(c, cor_pele, cor_pele_escura)
	# Braço do lado de CÁ (na frente de tudo) e o que ele segura
	var mao := _braco(Vector2(2, -64), braco_perto, cor_roupa, cor_pele)
	_desenhar_itens(mao)


func _cabeca_elefante(c: Vector2, pele: Color, escura: Color) -> void:
	draw_circle(c, 19.0, pele)
	_elipse(c + Vector2(-9, 2), Vector2(13, 16), escura)          # orelha grande
	# Tromba: começa no rosto e desce balançando
	var t1 := c + Vector2(15, 4)
	var t2 := t1 + Vector2(8, 10).rotated(sin(_tempo * 2.5) * 0.15)
	var t3 := t2 + Vector2(2, 10).rotated(sin(_tempo * 2.5 + 0.8) * 0.3)
	draw_polyline(PackedVector2Array([t1, t2, t3]), pele, 9.0, true)
	draw_circle(t3, 4.5, pele)
	draw_circle(c + Vector2(8, -5), 3.0, Color(0.1, 0.1, 0.12))   # olho
	draw_circle(c + Vector2(9, -6), 1.0, Color.WHITE)
	# Chapéu de chef
	draw_rect(Rect2(c + Vector2(-13, -30), Vector2(26, 14)), Color.WHITE)
	for p in [Vector2(-9, -36), Vector2(2, -40), Vector2(11, -35)]:
		draw_circle(c + p, 10.0, Color.WHITE)
	draw_line(c + Vector2(-13, -17), c + Vector2(13, -17), Color(0.85, 0.85, 0.88), 3.0)


func _cabeca_coelha(c: Vector2, pele: Color) -> void:
	# Orelhas compridas (balançam de leve)
	var o := sin(_tempo * 3.0) * 0.08
	for dx in [-6.0, 3.0]:
		var base := c + Vector2(dx, -12)
		_elipse_girada(base + Vector2(0, -16), Vector2(6, 17), o + dx * 0.02, pele)
		_elipse_girada(base + Vector2(0, -15), Vector2(3, 12), o + dx * 0.02, Color(1, 0.7, 0.78))
	draw_circle(c, 17.0, pele)
	draw_circle(c + Vector2(15, 2), 3.5, Color(1, 0.55, 0.65))    # nariz
	draw_circle(c + Vector2(6, -4), 3.0, Color(0.1, 0.1, 0.12))   # olho
	draw_circle(c + Vector2(7, -5), 1.0, Color.WHITE)
	draw_line(c + Vector2(-14, -10), c + Vector2(10, -16), Color(1.0, 0.45, 0.6), 4.0)  # lencinho


## Uma perna: do quadril até o pé, balançando como um pêndulo.
func _perna(quadril: Vector2, angulo: float, cor: Color) -> void:
	var pe := quadril + Vector2(sin(angulo), cos(angulo)) * COMP_PERNA
	draw_line(quadril, pe, cor, 10.0, true)
	_elipse(pe + Vector2(4, 0), Vector2(8, 4), Color(0.2, 0.18, 0.2))   # sapato


## Um braço de 2 partes. "angulos.x" = ombro, "angulos.y" = cotovelo.
## Devolve onde ficou a mão (para desenhar o que ele segura).
func _braco(ombro: Vector2, angulos: Vector2, cor_manga: Color, cor_mao: Color) -> Vector2:
	var cotovelo := ombro + Vector2(sin(angulos.x), cos(angulos.x)) * COMP_BRACO
	var a2 := angulos.x + angulos.y
	var mao := cotovelo + Vector2(sin(a2), cos(a2)) * COMP_BRACO
	draw_line(ombro, cotovelo, cor_manga, 9.0, true)
	draw_line(cotovelo, mao, cor_manga, 8.0, true)
	draw_circle(mao, 5.5, cor_mao)
	return mao


## Desenha os ingredientes (pequenos) ou o prato (maior) na mão.
func _desenhar_itens(mao: Vector2) -> void:
	for i in itens.size():
		var nome: String = itens[i]
		var tamanho := 22.0 if nome.begins_with("ing_") else 32.0
		var pos := mao + Vector2(-tamanho / 2.0 + 4.0, -tamanho + 2.0 - i * 12.0)
		draw_texture_rect(Estado.textura(nome), Rect2(pos, Vector2(tamanho, tamanho)), false)


func _elipse(centro: Vector2, raio: Vector2, cor: Color) -> void:
	_elipse_girada(centro, raio, 0.0, cor)


func _elipse_girada(centro: Vector2, raio: Vector2, giro: float, cor: Color) -> void:
	var pontos := PackedVector2Array()
	for i in 20:
		var a := TAU * i / 20.0
		pontos.append(centro + Vector2(cos(a) * raio.x, sin(a) * raio.y).rotated(giro))
	draw_colored_polygon(pontos, cor)
