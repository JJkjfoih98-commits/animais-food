extends RefCounted
## TABELAS DO JOGO (o lugar para mudar comidas, fases e missões!)
## Este arquivo só tem dados. Para usar em outro script:
##     const Dados = preload("res://scripts/dados.gd")
##     print(Dados.COMIDAS["pizza"]["preco"])

# ------------------------------------------------------------------ COMIDAS
# nome    = nome que aparece no jogo
# preco   = quanto o cliente paga (sem contar a gorjeta)
# preparo = segundos que o chef leva para cozinhar
# nivel   = nível do restaurante em que a comida é liberada
# (a imagem é assets/images/<chave>.png, ex.: assets/images/pizza.png)
const COMIDAS := {
	"suco":             {"nome": "Suco",              "preco": 8,  "preparo": 3.0,  "nivel": 1},
	"cupcake":          {"nome": "Cupcake",           "preco": 10, "preparo": 4.0,  "nivel": 1},
	"bolo":             {"nome": "Bolo",              "preco": 12, "preparo": 5.0,  "nivel": 1},
	"hamburguer":       {"nome": "Hambúrguer",        "preco": 15, "preparo": 6.0,  "nivel": 2},
	"batata":           {"nome": "Batata frita",      "preco": 11, "preparo": 4.5,  "nivel": 2},
	"sorvete":          {"nome": "Sorvete",           "preco": 9,  "preparo": 3.0,  "nivel": 3},
	"cafe":             {"nome": "Café",              "preco": 7,  "preparo": 2.5,  "nivel": 3},
	"pizza":            {"nome": "Pizza",             "preco": 18, "preparo": 8.0,  "nivel": 4},
	"sanduiche":        {"nome": "Sanduíche",         "preco": 13, "preparo": 5.0,  "nivel": 4},
	"donut":            {"nome": "Donut",             "preco": 10, "preparo": 4.0,  "nivel": 5},
	"panqueca":         {"nome": "Panqueca",          "preco": 14, "preparo": 6.0,  "nivel": 5},
	"salada":           {"nome": "Salada",            "preco": 12, "preparo": 4.0,  "nivel": 6},
	"sopa":             {"nome": "Sopa",              "preco": 16, "preparo": 7.0,  "nivel": 6},
	"espaguete":        {"nome": "Espaguete",         "preco": 20, "preparo": 8.0,  "nivel": 7},
	"milkshake":        {"nome": "Milkshake",         "preco": 12, "preparo": 3.5,  "nivel": 7},
	"taco":             {"nome": "Taco",              "preco": 17, "preparo": 6.0,  "nivel": 8},
	"pipoca":           {"nome": "Pipoca",            "preco": 9,  "preparo": 3.0,  "nivel": 8},
	"sushi":            {"nome": "Sushi",             "preco": 24, "preparo": 9.0,  "nivel": 9},
	"torta":            {"nome": "Torta",             "preco": 19, "preparo": 7.0,  "nivel": 9},
	"bolo_aniversario": {"nome": "Bolo de aniversário", "preco": 35, "preparo": 12.0, "nivel": 10},
}

# ------------------------------------------------------------------ CLIENTES
const ANIMAIS := ["coelho", "macaco", "pinguim", "leao", "tartaruga", "urso", "gato", "cachorro"]

# ------------------------------------------------------------------ NÍVEL DO RESTAURANTE
# Cada entrega dá XP. Juntando XP o restaurante sobe de nível e libera comidas.
const NIVEL_MAX := 10
const XP_POR_ENTREGA := 10

## Quanto XP precisa para passar do nível "nivel" para o próximo.
static func xp_para_subir(nivel: int) -> int:
	return 50 + 30 * (nivel - 1)

# ------------------------------------------------------------------ MISSÕES
# Tipos de missão que o jogo entende:
#   "servir"     -> sirva <meta> clientes
#   "ganhar"     -> ganhe <meta> dólares no dia
#   "combo"      -> entregue <meta> pratos seguidos sem errar e sem cliente bravo
#   "comida"     -> sirva <meta> pratos de <comida>
#   "rapido"     -> entregue um pedido em menos de <meta> segundos
#   "rajada"     -> sirva <meta> clientes em 20 segundos
#   "sem_bravo"  -> nenhum cliente vai embora bravo (conferido no fim)
#   "estrelas"   -> termine o dia com pelo menos <meta> estrelas de reputação
# Recompensa de cada missão: "dinheiro" e "xp".

# ------------------------------------------------------------------ FASES (os níveis do mapa)
# mesas      = quantas mesas o pátio tem
# duracao    = segundos do dia
# paciencia  = segundos que um cliente espera
# intervalo  = segundos entre um cliente e outro
# missoes    = 3 missões; cada missão cumprida vale 1 estrela da fase
const FASES := [
	{"mesas": 3, "duracao": 90, "paciencia": 50, "intervalo": 9.0, "missoes": [
		{"tipo": "servir", "meta": 3, "dinheiro": 20, "xp": 20},
		{"tipo": "ganhar", "meta": 40, "dinheiro": 20, "xp": 20},
		{"tipo": "sem_bravo", "meta": 0, "dinheiro": 30, "xp": 30}]},
	{"mesas": 3, "duracao": 90, "paciencia": 46, "intervalo": 8.0, "missoes": [
		{"tipo": "servir", "meta": 5, "dinheiro": 25, "xp": 25},
		{"tipo": "combo", "meta": 3, "dinheiro": 25, "xp": 25},
		{"tipo": "rapido", "meta": 20, "dinheiro": 30, "xp": 30}]},
	{"mesas": 4, "duracao": 90, "paciencia": 44, "intervalo": 7.5, "missoes": [
		{"tipo": "servir", "meta": 6, "dinheiro": 30, "xp": 30},
		{"tipo": "comida", "comida": "hamburguer", "meta": 2, "dinheiro": 30, "xp": 30},
		{"tipo": "ganhar", "meta": 100, "dinheiro": 35, "xp": 35}]},
	{"mesas": 4, "duracao": 95, "paciencia": 42, "intervalo": 7.0, "missoes": [
		{"tipo": "combo", "meta": 4, "dinheiro": 35, "xp": 35},
		{"tipo": "sem_bravo", "meta": 0, "dinheiro": 40, "xp": 40},
		{"tipo": "rajada", "meta": 2, "dinheiro": 40, "xp": 40}]},
	{"mesas": 5, "duracao": 95, "paciencia": 40, "intervalo": 6.5, "missoes": [
		{"tipo": "servir", "meta": 8, "dinheiro": 40, "xp": 40},
		{"tipo": "comida", "comida": "sorvete", "meta": 2, "dinheiro": 40, "xp": 40},
		{"tipo": "estrelas", "meta": 4, "dinheiro": 45, "xp": 45}]},
	{"mesas": 5, "duracao": 100, "paciencia": 38, "intervalo": 6.0, "missoes": [
		{"tipo": "ganhar", "meta": 180, "dinheiro": 45, "xp": 45},
		{"tipo": "combo", "meta": 5, "dinheiro": 45, "xp": 45},
		{"tipo": "rapido", "meta": 15, "dinheiro": 50, "xp": 50}]},
	{"mesas": 6, "duracao": 100, "paciencia": 36, "intervalo": 5.5, "missoes": [
		{"tipo": "servir", "meta": 10, "dinheiro": 50, "xp": 50},
		{"tipo": "sem_bravo", "meta": 0, "dinheiro": 55, "xp": 55},
		{"tipo": "comida", "comida": "pizza", "meta": 2, "dinheiro": 55, "xp": 55}]},
	{"mesas": 6, "duracao": 100, "paciencia": 34, "intervalo": 5.0, "missoes": [
		{"tipo": "ganhar", "meta": 250, "dinheiro": 55, "xp": 55},
		{"tipo": "rajada", "meta": 3, "dinheiro": 60, "xp": 60},
		{"tipo": "estrelas", "meta": 4, "dinheiro": 60, "xp": 60}]},
	{"mesas": 6, "duracao": 105, "paciencia": 32, "intervalo": 4.5, "missoes": [
		{"tipo": "servir", "meta": 12, "dinheiro": 65, "xp": 65},
		{"tipo": "combo", "meta": 6, "dinheiro": 65, "xp": 65},
		{"tipo": "rapido", "meta": 12, "dinheiro": 70, "xp": 70}]},
	{"mesas": 6, "duracao": 110, "paciencia": 30, "intervalo": 4.0, "missoes": [
		{"tipo": "servir", "meta": 14, "dinheiro": 80, "xp": 80},
		{"tipo": "sem_bravo", "meta": 0, "dinheiro": 90, "xp": 90},
		{"tipo": "estrelas", "meta": 5, "dinheiro": 100, "xp": 100}]},
]

## Texto da missão para mostrar na tela, ex.: "Sirva 5 clientes".
static func texto_missao(m: Dictionary) -> String:
	match m["tipo"]:
		"servir": return "Sirva %d clientes" % m["meta"]
		"ganhar": return "Ganhe $%d no dia" % m["meta"]
		"combo": return "Faça um combo de %d (sem errar)" % m["meta"]
		"comida": return "Sirva %d %s" % [m["meta"], COMIDAS[m["comida"]]["nome"]]
		"rapido": return "Entregue um pedido em menos de %d s" % m["meta"]
		"rajada": return "Sirva %d clientes em 20 segundos" % m["meta"]
		"sem_bravo": return "Nenhum cliente vai embora bravo"
		"estrelas": return "Termine com %d estrelas ou mais" % m["meta"]
	return "?"

# ------------------------------------------------------------------ MELHORIAS (loja)
const MELHORIAS := {
	"cadeiras": {"nome": "Cadeiras fofinhas", "desc": "Clientes esperam 20% mais", "preco": 80, "max": 3},
	"cardapio": {"nome": "Cardápio caprichado", "desc": "+$3 em cada pedido", "preco": 100, "max": 3},
	"fogao": {"nome": "Fogão turbo", "desc": "O chef cozinha 20% mais rápido", "preco": 90, "max": 3},
	"ajudante": {"nome": "Ajudante Coelha", "desc": "Uma 2ª cozinheira faz outro prato junto", "preco": 200, "max": 1},
}
