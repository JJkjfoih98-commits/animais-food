extends Node2D
## A GELADEIRA: guarda os ingredientes. A porta abre e fecha (animação).
## O desenho é feito por código. (0, 0) é o canto de cima à esquerda.

const TAMANHO := Vector2(70, 110)
## Onde o cozinheiro fica de pé para mexer na geladeira (relativo a ela).
const PONTO := Vector2(104, 112)

## 0 = porta fechada, 1 = porta aberta.
var porta := 0.0
## Ingredientes que aparecem nas prateleiras quando a porta abre.
var vitrine := ["ing_leite", "ing_ovo", "ing_queijo", "ing_tomate", "ing_morango", "ing_carne"]


func ponto() -> Vector2:
	return global_position + PONTO


## Abre a porta (use com await).
func abrir() -> void:
	var t := create_tween()
	t.tween_property(self, "porta", 1.0, 0.25)
	await t.finished


func fechar() -> void:
	var t := create_tween()
	t.tween_property(self, "porta", 0.0, 0.25)
	await t.finished


func _process(_delta: float) -> void:
	queue_redraw()


func _draw() -> void:
	var corpo := Rect2(Vector2.ZERO, TAMANHO)
	draw_rect(Rect2(Vector2(4, 6), TAMANHO), Color(0, 0, 0, 0.15))        # sombra
	draw_rect(corpo, Color(0.82, 0.9, 0.96))
	# Dentro (aparece quando a porta abre): luz, prateleiras e ingredientes
	if porta > 0.05:
		draw_rect(corpo.grow(-5), Color(0.95, 0.98, 1.0))
		for y in [38, 72]:
			draw_line(Vector2(6, y), Vector2(TAMANHO.x - 6, y), Color(0.7, 0.8, 0.9), 2.0)
		for i in vitrine.size():
			var pos := Vector2(9 + (i % 3) * 18, 18 + int(i / 3) * 34)
			draw_texture_rect(Estado.textura(vitrine[i]), Rect2(pos, Vector2(18, 18)), false)
	# A porta: presa do lado esquerdo; abrindo, ela "fica fininha" (como em 3D)
	var largura := TAMANHO.x * (1.0 - porta * 0.85)
	var p := Rect2(Vector2.ZERO, Vector2(largura, TAMANHO.y))
	draw_rect(p, Color(0.88, 0.94, 0.99))
	draw_rect(p, Color(0.55, 0.65, 0.75), false, 2.0)
	draw_line(Vector2(largura - 9, 20), Vector2(largura - 9, 46), Color(0.5, 0.55, 0.6), 4.0)  # puxador
	draw_line(Vector2(0, 52), Vector2(largura, 52), Color(0.6, 0.7, 0.8), 2.0)
	draw_rect(corpo, Color(0.55, 0.65, 0.75), false, 2.0)
