extends Node2D
## A MÁQUINA DE SORVETE: o cozinheiro puxa a alavanca, o creme cai do bico
## e enche o copinho. Faz sorvete e milkshake.

const TAMANHO := Vector2(64, 78)
const PONTO := Vector2(100, 80)        # onde o cozinheiro fica de pé
const BICO := Vector2(30, 46)          # de onde o creme sai
const ALAVANCA := Vector2(58, 18)      # onde a alavanca está presa

var comida := ""        # o que está sendo feito ("" = máquina parada)
var progresso := 0.0
var _tempo := 0.0


func ponto() -> Vector2:
	return global_position + PONTO


func _process(delta: float) -> void:
	_tempo += delta
	queue_redraw()


func _draw() -> void:
	draw_rect(Rect2(Vector2(4, 6), TAMANHO), Color(0, 0, 0, 0.15))
	# Corpo cor-de-rosa e o topo com as cores dos sabores
	draw_rect(Rect2(Vector2.ZERO, TAMANHO), Color(1.0, 0.78, 0.85))
	draw_rect(Rect2(Vector2(6, 4), Vector2(16, 12)), Color(1, 0.95, 0.85))
	draw_rect(Rect2(Vector2(24, 4), Vector2(16, 12)), Color(0.5, 0.3, 0.2))
	draw_rect(Rect2(Vector2(42, 4), Vector2(12, 12)), Color(1, 0.55, 0.65))
	# Alavanca: gira enquanto a máquina trabalha
	var giro := -0.3 + (sin(_tempo * 4.0) * 0.6 if comida != "" else 0.0)
	var ponta := ALAVANCA + Vector2(0, -22).rotated(giro)
	draw_line(ALAVANCA, ponta, Color(0.4, 0.4, 0.45), 4.0)
	draw_circle(ponta, 5, Color(0.9, 0.2, 0.3))
	# Bico e o espaço do copinho
	draw_rect(Rect2(Vector2(4, 40), Vector2(TAMANHO.x - 8, 34)), Color(0.85, 0.6, 0.68))
	draw_rect(Rect2(BICO + Vector2(-6, -4), Vector2(12, 8)), Color(0.75, 0.75, 0.8))
	if comida != "":
		# Gotas de creme caindo do bico
		for i in 3:
			var q := fmod(_tempo * 2.0 + i * 0.33, 1.0)
			draw_circle(BICO + Vector2(0, 6 + q * 14), 3.0, Color(1, 0.96, 0.88))
		# O prato aparece no copinho e vai crescendo
		var tam := 14.0 + 16.0 * progresso
		draw_texture_rect(Estado.textura(comida), Rect2(Vector2(BICO.x - tam / 2.0, 72 - tam), Vector2(tam, tam)), false)
	draw_rect(Rect2(Vector2.ZERO, TAMANHO), Color(0.65, 0.4, 0.5), false, 2.0)
